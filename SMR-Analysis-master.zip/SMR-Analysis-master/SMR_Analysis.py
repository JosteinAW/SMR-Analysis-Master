
import pandas as pd
from nordic490 import N490, plt
from analysis_components import AOperations
import analysis_components
from network_map import Map
import numpy as np
#from pypower.makePTDF import makePTDF


def showcaseNetwork(seperateNorway = False, simulationTime = '20180301:08', upgradeNetwork = False, gridUpgradeYear = 2021, plotMapZoom = None):
    """This function creates map plots that showcase the network topology for diffrent specification for a grid upgrade year."""
    if seperateNorway:
        m = N490(year=2035, set_branch_params=True, seperateCountry=[True, "NO"])
    else:
        m = N490(year=2035, set_branch_params=True)

    m_a = AOperations(m, simulationTime)

    if upgradeNetwork:
        m_a.fixkeyLines(year=gridUpgradeYear)
        m_a.upgradeLines(upgradeYear=gridUpgradeYear)

    m_a.m.distribute_power2(m_a.load, m_a.gen, m_a.link, gen_equals_load=False)
    #m_a.m.acpf(slackIsGreatestPV=True)
    m_a.m.dcpf()

    m_a.networkPlots(plotMapZoom)

def runShowcaseNetwork(type = 0):
    """This function creates map plots that showcase the network topology for the diffrent grid upgrades included in the case study."""
    if type == 0:
        showcaseNetwork()
        showcaseNetwork(seperateNorway = True)
        showcaseNetwork(seperateNorway = True, plotMapZoom= "Norway")
        showcaseNetwork(seperateNorway = True, plotMapZoom= "Norway", upgradeNetwork = True, gridUpgradeYear = 2021)
        showcaseNetwork(seperateNorway = True, plotMapZoom= "Norway", upgradeNetwork = True, gridUpgradeYear = 2030)
        showcaseNetwork(seperateNorway = True, plotMapZoom= "Norway", upgradeNetwork = True, gridUpgradeYear = 2045)
    if type == 1:
        showcaseNetwork(seperateNorway=True, plotMapZoom="South-Norway")
        showcaseNetwork(seperateNorway=True, plotMapZoom="North-Norway")

        showcaseNetwork(seperateNorway=True, plotMapZoom="South-Norway", upgradeNetwork=True, gridUpgradeYear=2021)
        showcaseNetwork(seperateNorway=True, plotMapZoom="North-Norway", upgradeNetwork=True, gridUpgradeYear=2021)

        showcaseNetwork(seperateNorway=True, plotMapZoom="South-Norway", upgradeNetwork=True, gridUpgradeYear=2030)
        showcaseNetwork(seperateNorway=True, plotMapZoom="North-Norway", upgradeNetwork=True, gridUpgradeYear=2030)


def showcaseNewLoads(slack = [True, 6374], simulationTime = '20180301:08', gridUpgradeYear = 2021, importCase = None, loadCase = 0, prodCase = 0, SMRCbus=None, plotMapZoom = "Norway", printPlotOptions = ["Full", ["SplitMap", "both"]]):
    """This function showcases placements of new loads within the network topology."""

    m = N490(year=2035, set_branch_params=True, seperateCountry=[True, "NO"])
    m_a = AOperations(m, simulationTime)

    # --- Configure Model and Setup Load Scenario and Production Case ---#
    m_a.nameUnknownBusses()
    m_a.fixkeyLines(year=gridUpgradeYear)
    m_a.upgradeLines(upgradeYear=gridUpgradeYear)

    m_a.loadCase(loadCase)
    m_a.prodCase(prodCase, clusterbus=SMRCbus)

    # --- Run Power Flow Simulation ---"
    if slack[0]:
        m_a.m.acpf(slackIsGreatestPV=True)
    elif not slack[0]:
        slack[0] = True
        m_a.m.acpf(customSlack=slack)
        # m_a.m.acpf(customSlack=[True, 6374])

    systemSlack = []
    systemSlack.append(int(m_a.m.solved_mpc[0][0]["bus"][m_a.m.solved_mpc[0][0]["bus"][:, 1] == 3][0, 0]))

    # Plot Results
    m_a.resultsPlots(plotMapZoom, printPlotOptions[1][1], slack=systemSlack, newloadPoints=m_a.loadCase(loadCase), newgenPoints=m_a.prodCase(prodCase, clusterbus=SMRCbus))







def findOptimalNode(simulationTime = '20180301:08', gridUpgradeYear = 2021, importCase = None, loadCase = 0, prodCase = 0, plotMapZoom = "Norway", printPlotOptions = ["Full", ["SplitMap", "both"]]):
    """This function find optimal busses within the network based on centrality algorithms."""
    #--- Setup of Model ---#
    m = N490(year=2035, set_branch_params=True, seperateCountry=[True, "NO"])

    m_a = AOperations(m, simulationTime)

    #--- Configure Model ---#
    m_a.nameUnknownBusses()
    m_a.fixkeyLines(year=gridUpgradeYear)
    m_a.upgradeLines(upgradeYear=gridUpgradeYear)

    # --- Run Network Algorithms ---#
    print("Betweenness Centrality ")
    m_a.betweennessCentrality()

    print("Closeness Centrality ")
    m_a.closenessCentrality()

    print("Eigenvector Centrality ")
    m_a.eigenvectorCentrality()

    print("Pagerank Centrality ")
    m_a.pageRankCentrality()

    """
    Setup for other centrality calculations:
    
    print("1: unweighted, 2: unweighted >=380KV, 3: weighted, 4: weighted >=380KV")
    m_a.pageRankCentrality()
    m_a.pageRankCentrality(onlyHighVoltage=[True, 380])
    m_a.pageRankCentrality(weighting="length")
    m_a.pageRankCentrality(weighting="length", onlyHighVoltage=[True,380])
    #m_a.pageRankCentrality(weighting="lengthAndVoltage")
    """

    # --- Setup Scenario and Case ---#
    m_a.importCase(importCase)

    m_a.m.distribute_power2(m_a.load, m_a.gen, m_a.link, gen_equals_load=False)

    m_a.loadCase(loadCase)
    m_a.prodCase(prodCase)

    #--- Run Power Flow Simulation ---"
    m_a.m.acpf(slackIsGreatestPV=True)

    systemSlack = []
    systemSlack.append(int(m_a.m.solved_mpc[0][0]["bus"][m_a.m.solved_mpc[0][0]["bus"][:,1] == 3][0,0]))

    #--- Generate Plot Results ---#
    #Plot Results
    m_a.resultsPlots(plotMapZoom, printPlotOptions[1][1], slack=systemSlack,  newloadPoints=m_a.loadCase(loadCase), newgenPoints=m_a.prodCase(prodCase))

def findPTDF(simulationTime = '20180301:08', gridUpgradeYear = 2021, importCase = None, loadCase = 1, prodCase = 0, plotMapZoom = "Norway", printPlotOptions = ["Full", ["SplitMap", "both"]]):
    """Unused and unfinished function. This function creates a PTDF Matrix."""

    # --- Setup of Model ---#
    m = N490(year=2035, set_branch_params=True, seperateCountry=[True, "NO"])

    m_a = AOperations(m, simulationTime)

    # --- Configure Model ---#
    m_a.nameUnknownBusses()
    m_a.fixkeyLines(year=gridUpgradeYear)
    m_a.upgradeLines(upgradeYear=gridUpgradeYear)

    # --- Setup Scenario and Case ---#
    m_a.importCase(importCase)

    m_a.m.distribute_power2(m_a.load, m_a.gen, m_a.link, gen_equals_load=False)

    newLoadPoints = m_a.loadCase(loadCase)
    newGenPoints = m_a.prodCase(prodCase)

    # --- Run Power Flow Simulation ---"
    m_a.m.acpf(slackIsGreatestPV=True)

    systemSlack = []
    systemSlack.append(int(m_a.m.solved_mpc[0][0]["bus"][m_a.m.solved_mpc[0][0]["bus"][:, 1] == 3][0, 0]))
                                                                            #m_a.m.line[1240],  m_a.m.bus[,0] = 6200
    busVoltagesDrops, overLoadedLines = m_a.resultsPrints(printFull=False)  #overLoadedLines.index = 1242 etc.
    PTDFMatrix = m_a.calculate_ptdf(m_a.m.solved_mpc[0][0])  #[branch,Bus] = [0-2,1] etc.

    # Combine the newLoadPoints and newGenPoints
    if newGenPoints is not None:
        allPoints = set(newLoadPoints + newGenPoints)
    else:
        allPoints = set(newLoadPoints)

    # Identify the column indices for the buses you're interested in
    bus_indices = [m_a.m.bus.index.get_loc(bus_id) for bus_id in allPoints if bus_id in m_a.m.bus.index]
    bus_ids = [bus_id for bus_id in allPoints if bus_id in m_a.m.bus.index]

    # Identify the row indices for the lines you're interested in
    line_indices = [m_a.m.line.index.get_loc(line_id) for line_id in overLoadedLines.index if
                    line_id in m_a.m.line.index]
    line_ids = [line_id for line_id in overLoadedLines.index if line_id in m_a.m.line.index]

    # Create the new matrix with the values of interest
    newMatrix_values = PTDFMatrix[np.ix_(line_indices, bus_indices)]

    # Convert to DataFrame with the correct indices
    newMatrix = pd.DataFrame(newMatrix_values, index=line_ids, columns=bus_ids)

    # Output the new matrix
    print(newMatrix)


def runCase(slack = [True, 6374], simulationTime = '20180301:08', gridUpgradeYear = 2021, importCase = None, loadCase = 0, prodCase = 0, SMRCbus=None, plotMapZoom = "Norway", printPlotOptions = ["Full", ["SplitMap", "both"]]):
    """This function runs a specified case from a preset selection of cases, and prints and plots the results."""

    #--- Setup of Model ---#
    m = N490(year=2035, set_branch_params=True, seperateCountry=[True, "NO"])

    m_a = AOperations(m, simulationTime)

    #--- Configure Model and Setup Load Scenario and Production Case ---#
    m_a.nameUnknownBusses()
    m_a.fixkeyLines(year=gridUpgradeYear)
    m_a.upgradeLines(upgradeYear=gridUpgradeYear)

    m_a.importCase(importCase)

    m_a.m.distribute_power2(m_a.load, m_a.gen, m_a.link, gen_equals_load=False)

    m_a.loadCase(loadCase)
    m_a.prodCase(prodCase, clusterbus=SMRCbus)

    #--- Run Power Flow Simulation ---"
    if slack[0]:
        m_a.m.acpf(slackIsGreatestPV=True)
    elif not slack[0]:
        slack[0] = True
        m_a.m.acpf(customSlack=slack)
        #m_a.m.acpf(customSlack=[True, 6374])

    systemSlack = []
    systemSlack.append(int(m_a.m.solved_mpc[0][0]["bus"][m_a.m.solved_mpc[0][0]["bus"][:,1] == 3][0,0]))

    #--- Print and plot results ---#
    #Print Results
    if printPlotOptions[0] == "Full":
        print("\n")
        print("|================================================================================|")
        print("Load Case: " + str(loadCase))
        print("Production Case: " + str(prodCase))

        m_a.genPmaxViolation()
        m_a.genQmaxViolation()
        m_a.slackGenInjection()
        busVoltagesDrops, overLoadedLines = m_a.resultsPrints(costTime=gridUpgradeYear)

    elif printPlotOptions[0] == "Essential":
        print("\n")
        print("|================================================================================|")
        print("Load Case: " + str(loadCase))
        print("Production Case: " + str(prodCase))
        m_a.slackGenInjection()
        m_a.genPmaxViolation()
        busVoltagesDrops, overLoadedLines = m_a.resultsPrints(costTime=gridUpgradeYear)


    elif printPlotOptions[0] == "Minimal":
        print("\n")
        print("|================================================================================|")
        print("Load Case: " + str(loadCase))
        print("Production Case: " + str(prodCase))
        busVoltagesDrops, overLoadedLines = m_a.resultsPrints(printFull=False)

    #Plot Results
    if printPlotOptions[1][0] == "Full":
        m_a.resultsPlots(plotMapZoom, printPlotOptions[1][1], slack=systemSlack, newloadPoints=m_a.loadCase(loadCase), newgenPoints=m_a.prodCase(prodCase, clusterbus=SMRCbus))
        m_a.resultsPlots("South-Norway", printPlotOptions[1][1], slack=systemSlack, newloadPoints=m_a.loadCase(loadCase), newgenPoints=m_a.prodCase(prodCase, clusterbus=SMRCbus))
        m_a.resultsPlots("North-Norway", printPlotOptions[1][1], slack=systemSlack, newloadPoints=m_a.loadCase(loadCase), newgenPoints=m_a.prodCase(prodCase, clusterbus=SMRCbus))
        m_a.lineLoadingBarChart(overLoadedLines)
        m_a.busVoltageBarChart(busVoltagesDrops)

    elif printPlotOptions[1][0] == "SplitMap":
        m_a.resultsPlots("South-Norway", printPlotOptions[1][1], slack=systemSlack, newloadPoints=m_a.loadCase(loadCase), newgenPoints=m_a.prodCase(prodCase, clusterbus=SMRCbus))
        m_a.resultsPlots("North-Norway", printPlotOptions[1][1], slack=systemSlack, newloadPoints=m_a.loadCase(loadCase), newgenPoints=m_a.prodCase(prodCase, clusterbus=SMRCbus))
        m_a.lineLoadingBarChart(overLoadedLines)
        m_a.busVoltageBarChart(busVoltagesDrops)

    elif printPlotOptions[1][0] == "Essential":
        m_a.resultsPlots(plotMapZoom, printPlotOptions[1][1], slack=systemSlack,  newloadPoints=m_a.loadCase(loadCase), newgenPoints=m_a.prodCase(prodCase, clusterbus=SMRCbus))



def runAnalysis(type = 0, printAndPlotOptions = ["Full", ["SplitMap", "both"]]):
    """This function runs the anlaysis of the case study."""
    if type == 0: #State in system 2018
        runCase(printPlotOptions=printAndPlotOptions)
    elif type == 1:
        #Load Increase Scenario 1, grid 2021
        runCase(loadCase=1, printPlotOptions=printAndPlotOptions)

        # Load Increase Scenario 1, Co-located SMR Production
        runCase(loadCase=1, prodCase=1, printPlotOptions=printAndPlotOptions)

        # Load Increase Scenario 1, Cluster SMR Production
        #runCase(loadCase=1, prodCase=5, printPlotOptions=printAndPlotOptions)
        runCase(loadCase=1, prodCase=7, printPlotOptions=printAndPlotOptions)

        # Load Increase Scenario 1, Offshore Wind Production
        runCase(loadCase=1, prodCase=11, printPlotOptions=printAndPlotOptions)

        # Load Increase Scenario 1, Import Sweden
        #runCase(loadCase=1, importCase = "Sweden", printPlotOptions=printAndPlotOptions)
        # Load Increase Scenario 1, Import Western Europe
        runCase(loadCase=1, importCase = "West-Europe", printPlotOptions=printAndPlotOptions)

    elif type == 2:
        #Load Increase Scenario 1, grid 2030
        runCase( loadCase=1, gridUpgradeYear=2030, printPlotOptions=printAndPlotOptions)

        # Load Increase Scenario 1, Co-located SMR Production
        runCase(loadCase=1, prodCase=1, gridUpgradeYear=2030, printPlotOptions=printAndPlotOptions)

        # Load Increase Scenario 1, Cluster SMR Production
        #runCase(loadCase=1, prodCase=5 , gridUpgradeYear=2030, printPlotOptions=printAndPlotOptions)
        runCase(loadCase=1, prodCase=7, SMRCbus=6464, gridUpgradeYear=2030, printPlotOptions=printAndPlotOptions)
        runCase(loadCase=1, prodCase=7, gridUpgradeYear=2030, printPlotOptions=printAndPlotOptions)
        runCase(loadCase=1, prodCase=7, SMRCbus=6481, gridUpgradeYear=2030, printPlotOptions=printAndPlotOptions)

        # Load Increase Scenario 1, Offshore Wind Production
        runCase(loadCase=1, prodCase=11, gridUpgradeYear=2030, printPlotOptions=printAndPlotOptions)

        # Load Increase Scenario 1, Import Western Europe
        runCase(loadCase=1, importCase = "West-Europe", gridUpgradeYear=2030, printPlotOptions=printAndPlotOptions)

    elif type == 3:
        #Load Increase Scenario 1, grid 2045
        runCase( loadCase=5, gridUpgradeYear=2045, printPlotOptions=printAndPlotOptions)

        # Load Increase Scenario 1, Co-located SMR Production
        runCase(loadCase=5, prodCase=2, gridUpgradeYear=2045, printPlotOptions=printAndPlotOptions)

        # Load Increase Scenario 1, Cluster SMR Production
        #runCase(loadCase=1, prodCase=5 , gridUpgradeYear=2030, printPlotOptions=printAndPlotOptions)
        runCase(loadCase=5, prodCase=8, SMRCbus=6464, gridUpgradeYear=2045, printPlotOptions=printAndPlotOptions)
        runCase(loadCase=5, prodCase=8, gridUpgradeYear=2045, printPlotOptions=printAndPlotOptions)
        runCase(loadCase=5, prodCase=8, SMRCbus=6481, gridUpgradeYear=2045, printPlotOptions=printAndPlotOptions)

        # Load Increase Scenario 1, Offshore Wind Production
        runCase(loadCase=5, prodCase=12, gridUpgradeYear=2045, printPlotOptions=printAndPlotOptions)

        # Load Increase Scenario 1, Import both
        runCase(loadCase=5, importCase = "Both", gridUpgradeYear=2045, printPlotOptions=printAndPlotOptions)
    elif type == 4:

        runCase(loadCase=1, prodCase=7, SMRCbus=6464, gridUpgradeYear=2030, printPlotOptions=printAndPlotOptions)
        runCase(loadCase=1, prodCase=7, SMRCbus=6465, gridUpgradeYear=2030, printPlotOptions=printAndPlotOptions)
        runCase(loadCase=1, prodCase=7, SMRCbus=6481, gridUpgradeYear=2030, printPlotOptions=printAndPlotOptions)

        runCase(loadCase=5, prodCase=8, SMRCbus=6464, gridUpgradeYear=2045, printPlotOptions=printAndPlotOptions)
        runCase(loadCase=5, prodCase=8, SMRCbus=6465, gridUpgradeYear=2045, printPlotOptions=printAndPlotOptions)
        runCase(loadCase=5, prodCase=8, SMRCbus=6481, gridUpgradeYear=2045, printPlotOptions=printAndPlotOptions)

        #runCase(loadCase=1, importCase="West-Europe", gridUpgradeYear=2030, printPlotOptions=printAndPlotOptions)
        #runCase(loadCase=5, importCase="Both", gridUpgradeYear=2045, printPlotOptions=printAndPlotOptions)




#runAnalysis(type=1, printAndPlotOptions=["Essential",["Full","both"]])







def Main():
    """Run the SMR analysis case study."""
    #runShowcaseNetwork()
    #showcaseNewLoads()

    #findOptimalNode(gridUpgradeYear=2030)
    #findOptimalNode(gridUpgradeYear=2045)

    runAnalysis(type=2, printAndPlotOptions=["Essential",["Full","both"]])
    runAnalysis(type=3, printAndPlotOptions=["Essential",["Full","both"]])


Main()