# -*- coding: utf-8 -*-
"""
Created on Tue Oct 23 12:48:13 2018

@author: jolauson

Edited

@by : Aravind

"""

import logging
import math
import os
import pickle

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from numpy import atleast_1d as arr
from numpy import flatnonzero as find

from pypower.api import ppoption, rundcpf, runopf #, runpf      # SMR Analysis adjustment (import runpf)
from runpfV514 import runpf  ## SMR Analysis adjustment
# One needs to update runpf to PyPower Version 5.14 in order to make enforce_gen_limits = True to work. This have been done by importing runpf in this way.

from scipy.io import savemat
from scipy.spatial.distance import cdist

import entsoe_transparency_db as entsoe
import nordpool_db as nordpool
from network_map import Map

logger = logging.getLogger("Nordic490.nordic490")

#warnings = False  # Display warnings
warnings = True  # Display warnings

def mult_ind(a, b, miss=np.nan):
    """Get indices for elements of a in b, returns numpy array.
    E.g. mult_ind([1,2,1,4],[3,2,1]) -> array([2.,1.,2.,nan])"""
    bind = {}
    for i, elt in enumerate(b):
        if elt not in bind:
            bind[elt] = i
    return arr([bind.get(itm, miss) for itm in a])


class N490:
    def __init__(self, topology_file="Data", year=True, set_branch_params=False, seperateCountry=[False, None]):
        """Initiate object
        year: remove too old or not yet built. None -> include everything, True -> current year"""

        self.baseMVA = 100.0  # base MVA
        self.dfs = [
            "bus",
            "gen",
            "line",
            "link",
            "trafo",
            "farms",
        ]  # dataframes to read
        self.bidz = [
            "SE1",
            "SE2",
            "SE3",
            "SE4",
            "NO1",
            "NO2",
            "NO3",
            "NO4",
            "NO5",
            "FI",
            "DK2",
        ]  # Price areas in the Nordics
        self.country = ["SE", "NO", "FI", "DK"]  # Countries in the model
        self.gen_type = [
            "Nuclear",
            "Hydro",
            "Thermal",
            "Wind",
        ]  # Main gen types
        self.load_data(topology_file)  # load network data from xlsx, npy etc.
        self.prepare_network(year)  # possibly remove too new or old data, check islands
        if seperateCountry[0]:
            self.separate_country(seperateCountry)
        self.flow_measured = []  # store measured AC flows between areas
        self.flow_modelled = []  # store modelled -"- from e.g. dcpf()
        self.solved_mpc = []  # store solved cases
        self.time = 0  # store time when downloading from entso-e and nordpool
        if set_branch_params:
            self.branch_params()

    def load_data(self, topology_file):
        """Load file with network topology (folder with pkl / excel / raw / matpower)"""

        ext = os.path.splitext(topology_file)[1]  # file extension
        if ext == "":  # folder with pkl files
            for df in self.dfs:
                setattr(
                    self,
                    df,
                    pd.read_pickle(os.path.join(topology_file, "%s.pkl" % df)),
                )

        elif ext == ".xlsx":
            for df in self.dfs:
                setattr(self, df, pd.read_excel(topology_file, df, index_col=0))

        elif ext == ".raw":
            logger.info("loading from .raw not implemented yet")

        elif ext == ".mat":
            logger.info("loading from .mat not implemented yet")

    def prepare_network(self, year):
        """Remove dismantled or not yet constructed equipment, check islands etc."""

        if year is True:
            year = pd.Timestamp.now().year

        # remove decommissioned/under construction equipment
        if year is not None:
            for df in self.dfs:
                data = getattr(self, df)
                data.drop(data[data.uc > year].index, inplace=True)  # not yet constructed
                data.drop(data[(data.uc < 0) & (-data.uc <= year)].index, inplace=True)  # dismantled

        # remove island buses
        ibus = self.find_islands()
        if len(ibus) > 0:
            self.bus.drop(ibus, axis=0, inplace=True)
            if warnings:
                logger.info("The following island buses were removed: %s" % str(ibus))

        # wind power
        f = self.farms
        f.drop(f[(f.status > 1) & ~f.uc].index, inplace=True)  # remove non-operational wind farms
        # existing wind farms on removed buses (iloc) -> find closest existing bus
        ind = find(np.isnan(mult_ind(f.bus, self.bus.index)))
        d = cdist(
            arr(f.iloc[ind, mult_ind(["x", "y"], list(f))]),
            arr(self.bus.loc[:, ["x", "y"]]),
        )
        bus = arr(self.bus.index[np.argmin(d, axis=1)])
        f.iloc[ind, list(f).index("bus")] = bus

        # update load_shares
        for b in self.bidz:
            sum_share = self.bus.loc[self.bus.bidz == b, "load_share"].sum()
            self.bus.loc[self.bus.bidz == b, "load_share"] *= 1 / sum_share

        # Adding fictitious thermal power stations to SE1 and SE2
        self.fictThermalGen = pd.DataFrame(
            [
                {
                    "name": "test",
                    "type": "Thermal",
                    "type2": "oil",
                    "Pmax": 1000,
                    "bidz": "SE1",
                    "bus": 6666,
                    "uc": 0,
                    "country": "SE",
                },  # 6672
                {
                    "name": "test",
                    "type": "Thermal",
                    "type2": "oil",
                    "Pmax": 1000,
                    "bidz": "SE2",
                    "bus": 6540,
                    "uc": 0,
                    "country": "SE",
                },  # 6391
            ],
            index=[9999, 9998],
        )
        self.gen = self.gen._append(self.fictThermalGen) #OBS! SMR Analysis adjustment, Changes necesary so gen does not get overwriten! Changed gen to fictThermalGen, then append it to self.gen.


    def separate_country(self, seperateCountry=[False, None]):  ## SMR Analysis adjustment
        """This function seperates out the grid for one of the Nordic nations from the rest of the model"""
        if seperateCountry[0] == True:

            selectedCountry = seperateCountry[1]
            droppedCountries = [item for item in self.country if item != selectedCountry]
            droppedBidz = [item for item in self.bidz if not item.startswith(selectedCountry)]
            includedBidz = [item for item in self.bidz if item.startswith(selectedCountry)]

            for df in self.dfs:
                data = getattr(self, df)
                if df in ["bus", "gen", "farms"]:
                    data.drop(data[data["country"].isin(droppedCountries)].index, inplace=True)

                elif df == "line":
                    newInterconnections = data[((data['area0'].isin(includedBidz)) & (data['area1'].isin(droppedBidz))) | ((data['area1'].isin(includedBidz)) & (data['area0'].isin(droppedBidz)))]
                    data.drop(newInterconnections.index, inplace=True)
                    data.drop(data[data["area0"].isin(droppedBidz)].index, inplace=True)
                    data.drop(data[data["area1"].isin(droppedBidz)].index, inplace=True)

                    commonColumns = self.link.columns.intersection(newInterconnections.columns)
                    newInterconnections = newInterconnections[commonColumns]
                    newInterconnections['name'] = newInterconnections['area0'] + ' - ' + newInterconnections['area1']
                    newInterconnections = newInterconnections[self.link.columns]

                elif df in ["link", "trafo"]:
                    data.drop(data[data["area0"].isin(droppedBidz)].index, inplace=True)
                    data.drop(data[data["area1"].isin(droppedBidz)].index, inplace=True)
                    if df in ["link"]:
                        updated_link = data._append(newInterconnections, ignore_index=True)
                        setattr(self, 'link', updated_link)

    def branch_params(self):
        """Assigning branch parameters for the lines
        Note: X and B are per phase!"""

        ohm_per_km = [0.246, 0.265, 0.301]  # for [380, 300, <=220] kV lines
        S_per_km = [
            100 * 3.14 * 13.8e-9,
            100 * 3.14 * 13.2e-9,
            100 * 3.14 * 12.5e-9,
        ]  # line charging susceptance [380, 300, <=220] kV lines in Ohm*km
        compensate = [
            0.5,
            380,
            200,
        ]  # Series compensation for long high-voltage lines [compensation factor, min voltage (kV), min length (km)]
        trafo_x = [
            2.8e-2,
            4e-2,
            7e-2,
        ]  # transformer pu reactance for [380,300,<300] kV
        XR = [
            8.2,
            6.625,
            5.01667,
            50,
        ]  # X/R for 380, 300, 220 kV lines and transformers respectively
        line, trafo = self.line, self.trafo

        # Assigning reactance to corresponding lines
        line["X"] = ohm_per_km[2] * line["length"] / 1000 / line["Vbase"] ** 2 * self.baseMVA
        line.loc[line.Vbase == 380, "X"] = ohm_per_km[0] * line["length"] / 1000 / line["Vbase"] ** 2 * self.baseMVA
        line.loc[line.Vbase == 300, "X"] = ohm_per_km[1] * line["length"] / 1000 / line["Vbase"] ** 2 * self.baseMVA

        # Assigning resistance to corresponding lines
        line["R"] = ohm_per_km[2] * line["length"] / 1000 / line["Vbase"] ** 2 * self.baseMVA / XR[2]
        line.loc[line.Vbase == 380, "R"] = (
            ohm_per_km[0] * line["length"] / 1000 / line["Vbase"] ** 2 * self.baseMVA / XR[0]
        )
        line.loc[line.Vbase == 300, "R"] = (
            ohm_per_km[1] * line["length"] / 1000 / line["Vbase"] ** 2 * self.baseMVA / XR[1]
        )

        # Assigning compensation factor to long transmission lines
        comp = (line.Vbase >= compensate[1]) & (line.length >= compensate[2] * 1000) & (line.area0 == "SE3")
        line.loc[comp, "X"] -= compensate[0] * line.loc[comp, "X"]

        # Assigning capacities to corresponding lines
        # Start with creating a dictionary that links Vbase ranges in kV to Capacities per circuit in MW
        thermal_cap_per_circuit = dict()
        for voltage in set(line.Vbase):
            if 130 <= voltage <= 150:
                thermal_cap_per_circuit[voltage] = 150
            elif 220 <= voltage <= 245:
                thermal_cap_per_circuit[voltage] = 492 # SMR Analysis adjustment
            elif 300 == voltage:
                thermal_cap_per_circuit[voltage] = 1005 # SMR Analysis adjustment
            elif 380 <= voltage <= 400:
                thermal_cap_per_circuit[voltage] = 1698 # SMR Analysis adjustment
            else:
                thermal_cap_per_circuit[voltage] = "Unknown"
        line["Cap"] = 0
        for voltage in thermal_cap_per_circuit:
            if thermal_cap_per_circuit[voltage] != "Unknown":
                line.loc[line.Vbase == voltage, "Cap"] = thermal_cap_per_circuit[voltage] * line.circuits

        # Line Charging susceptance
        # line['B'] = S_per_km[2] * line['length'] / 1000 * line['Vbase'] ** 2 / self.baseMVA
        # line.loc[line.Vbase == 380, 'B'] = S_per_km[0] * line['length'] / 1000 * line['Vbase'] ** 2 / self.baseMVA
        # line.loc[line.Vbase == 300, 'B'] = S_per_km[1] * line['length'] / 1000 * line['Vbase'] ** 2 / self.baseMVA
        line["B"] = S_per_km[2] / (line["length"] / 1000) / line["Vbase"] ** 2 * self.baseMVA
        line.loc[line.Vbase == 380, "B"] = S_per_km[0] / (line["length"] / 1000) / line["Vbase"] ** 2 * self.baseMVA
        line.loc[line.Vbase == 300, "B"] = S_per_km[1] / (line["length"] / 1000) / line["Vbase"] ** 2 * self.baseMVA

        # transformers
        # Include this section if turns ratio is not included in the transformer database
        """ 
        v0 = self.bus.loc[trafo.bus0, 'Vbase']  # voltage at bus0
        v1 = self.bus.loc[trafo.bus1, 'Vbase']  # voltage at bus1
        v0_array = [_ for _ in v0]
        v1_array = [_ for _ in v1]
        v = arr(np.maximum(v0_array, v1_array)) # to find maximum voltage
        turn = [x/y for x, y in zip(v0_array, v1_array)] # calculating the turns ratio for each transformer
        trafo['ratio'] = turn
        self.trafo['ratio'] = turn
        """
        trafo.loc[trafo.ratio == 132 / 380, "X"] = trafo_x[0]
        trafo.loc[trafo.ratio == 220 / 380, "X"] = trafo_x[0]
        trafo.loc[trafo.ratio == 300 / 380, "X"] = trafo_x[0]
        trafo.loc[trafo.ratio == 132 / 300, "X"] = trafo_x[1]
        trafo.loc[trafo.ratio == 220 / 300, "X"] = trafo_x[1]
        trafo.loc[trafo.ratio == 132 / 220, "X"] = trafo_x[2]
        trafo["R"] = trafo["X"] / XR[3]
        trafo["B"] = 0

    def mpc2network(self, num=0):
        """Extract data (flows etc) from solved case and add info to self.bus etc.
        More parameters to be added later (e.g. after AC simulation)"""
        mpc = self.solved_mpc[num][0]
        self.bus["angle"] = mpc["bus"][:, 8]
        self.bus["Voltage (pu)"] = mpc["bus"][:, 7] # SMR Analysis adjustment, Buss/Node Voltage (pu)

        line = mpc["branch"][mpc["branch"][:, 8] == 0]
        self.line["flow"] = line[:, 13]

        # SMR Analysis adjustment
        self.line["Q flow"] = line[:, 14]
        #self.line["Line Loading"] = abs(line[:, 13]/line[:, 5]*100) # SMR Analysis adjustment
        self.line["Line Loading"] = abs(np.sqrt(np.power(line[:, 13],2) + np.power(line[:, 14],2)) / line[:, 5] * 100)

        trafo = mpc["branch"][mpc["branch"][:, 8] == 1]
        self.trafo["flow"] = trafo[:, 13]

    def get_measurements(self, start, stop=None, adjust_gen=True):
        """Import load, generation per type and HVDC from entso-e and Nordpool.
        start/stop can be strings 'yyyymmdd:hh' or pd.Timestamp (UTC+1)
        adjust_gen: True to adjust entso-e data based on Nordpool totals
        data for 2015-2018 is available (entsoe_transparency_db and nordpool_db to download more).
        """

        # Main gen type for each entso-e type
        gen_key = {
            "Biomass": "Thermal",
            "Gas": "Thermal",
            "Hard coal": "Thermal",
            "Hydro": "Hydro",
            "Hydro res": "Hydro",
            "Hydro ror": "Hydro",
            "Nuclear": "Nuclear",
            "Oil": "Thermal",
            "Other": "Thermal",
            "Other renew": "Thermal",
            "Peat": "Thermal",
            "Solar": "Wind",
            "Thermal": "Thermal",
            "Waste": "Thermal",
            "Wind": "Wind",
            "Wind offsh": "Wind",
            "Wind onsh": "Wind",
        }

        # Adjust exchange areas from Nordpool, e.g. SE-PL becomes SE4-PL
        exch_fix = {
            "SE-PL": "SE4-PL",
            "SE-DE": "SE4-DE",
            "NO-DK": "NO2-DK1",
            "NO-NL": "NO2-NL",
            "NO-FI": "NO4-FI",
            "NO-RU": "NO4-RU",
        }

        def timestamp(s):
            return pd.to_datetime(s, format="%Y%m%d:%H")  # 'yyyymmdd:hh' to pd.Timestamp

        def empty_df(area, typ, time, fill=0.0):
            """Make empty DataFrame with (area,type) as columns and time as index."""
            index = pd.MultiIndex.from_product([area, typ], names=["area", "type"])
            df = pd.DataFrame(fill, index=time, columns=index)
            return df

        def fix_entsoe(dic, limit=10):
            """Handle DST shift and interpolate remaining nans.
            Error if time starts with last sunday in october 02:00..."""

            time = dic[list(dic)[0]].index
            month, day, wd, hour = time.month, time.day, time.weekday, time.hour
            shift = find((month == 10) & (wd == 6) & (hour == 2) & (day > 24))  # DST shift hours in October
            for i, df in dic.items():
                if i in self.bidz:
                    # DST shift in October
                    for s in shift:
                        if sum(np.isnan(df.iloc[s, :])) > 0 and sum(df.iloc[s - 1, :]) / sum(df.iloc[s - 2, :]) > 1.5:
                            df.iloc[s - 1, :] /= 2
                            df.iloc[s, :] = df.iloc[s - 1, :]

                    # Remaining nans
                    df = df.astype(float)
                    df.interpolate(limit=limit, inplace=True)  # interpolate up to limit samples

                    if df.isna().sum().sum() > 0:
                        logger.info("Too many nans in Entso-e data for %s, might not work properly." % i)
            return dic

        if type(start) == type(pd.Timestamp(2018)):
            start = start.strftime("%Y%m%d:%H")
        if type(stop) == type(pd.Timestamp(2018)):
            stop = stop.strftime("%Y%m%d:%H")
        if stop is not None:
            time = pd.date_range(timestamp(start), timestamp(stop), freq="h")
        else:
            time = [timestamp(start)]
            stop = start

        # Entso-e generation
        db = entsoe.Database()
        raw = db.select_gen_per_type_wrap(starttime=start, endtime=stop)
        #raw = fix_entsoe(raw)
        gen = empty_df(self.bidz, self.gen_type, time)
        for b in self.bidz:
            for t in list(raw[b]):  # iterate over gen types
                gen.loc[:, (b, gen_key[t])] += arr(raw[b][t])[0]

        # Possibly adjust entso-e generation so sum equals Nordpool
        db = nordpool.Database()
        if adjust_gen:
            gen_np = db.select_data(table="production", starttime=start, endtime=stop)
            for b in self.bidz:
                ratio = arr(gen_np[b] / gen.loc[:, b].sum(axis=1))
                for t in self.gen_type:
                    gen.loc[:, (b, t)] *= ratio[0]

        # Nordpool load
        load = db.select_data(table="consumption", starttime=start, endtime=stop).loc[:, self.bidz]

        # Nordpool exchange (both AC and DC)
        exch_np = db.select_data(table="exchange", starttime=start, endtime=stop)
        cols = [c.replace(" ", "") for c in list(exch_np)]  # no blanks
        for k, v in exch_fix.items():
            try:
                cols[cols.index(k)] = v  # change e.g. SE-PL to SE4-PL
            except ValueError:
                pass
        exch = pd.DataFrame(index=time)
        for e, v in zip(cols, arr(exch_np).T):  # save relevant exchanges
            a0, a1 = e.split("-")
            if a0 in self.bidz or a1 in self.bidz:  # exclude e.g. LV-RU
                if not (a0 in self.country and a1 in self.country):  # exclude e.g. SE-FI
                    if a0 > a1:
                        exch.loc[:, "%s-%s" % (a1, a0)] = -v  # in alphabetic order
                    else:
                        exch.loc[:, "%s-%s" % (a0, a1)] = v

        # DC exchange
        link = pd.DataFrame(index=time)
        nn = 0  # keep track of Nordpool exchanges with counterpart in model
        for i in list(exch):
            a0, a1 = i.split("-")
            ind1 = self.link.index[(self.link.area0 == a0) & (self.link.area1 == a1)]  # find links between areas
            ind2 = self.link.index[(self.link.area0 == a1) & (self.link.area1 == a0)]  # -"- but reverse flow direction
            num = len(ind1) + len(ind2)  # number of links in model for this exchange
            if num > 0:
                nn += 1
                for i1 in ind1:
                    link.loc[:, i1] = arr(exch.loc[:, i] / num)  # later set exchange based on link capacity
                for i2 in ind2:
                    link.loc[:, i2] = -arr(exch.loc[:, i] / num)

        # AC exchange between areas
        ac_flow = pd.DataFrame(index=time)
        for i in list(exch):
            a0, a1 = i.split("-")
            ind1 = self.line.index[(self.line.area0 == a0) & (self.line.area1 == a1)]  # find lines between areas
            ind2 = self.line.index[(self.line.area0 == a1) & (self.line.area1 == a0)]  # -"- but reverse flow direction
            if len(ind1) + len(ind2) > 0:  # we have an AC connection
                nn += 1
                if self.bidz.index(a0) < self.bidz.index(a1):  # "first" bid zone should be first
                    ac_flow.loc[:, i] = exch.loc[:, i]
                else:
                    ac_flow.loc[:, "%s-%s" % (a1, a0)] = -exch.loc[:, i]

        # Check that all Nordpool exchanges has been taken into account
        if exch.shape[1] != nn and warnings:
            logger.info("Some Nordpool exchanges are not included in model")

        self.flow_measured = ac_flow
        self.flow_modelled = pd.DataFrame(0.0, index=time, columns=list(ac_flow))
        self.time = time

        return load, gen, link

    def time_series(self, start, stop):
        """Download hourly time series between start and stop and run dc power flow for each hour."""

        logger.info("*** Accessing data from Entso-E and Nordpool ***")
        load, gen, link = self.get_measurements(start, stop)
        logger.info("*** Distributing power and running DCPF ***")
        day = "yyyy-mm-dd"  # print progress each day
        for n, t in enumerate(self.time):
            self.distribute_power(load, gen, link, n, gen_equals_load=True)
            self.dcpf(n, save2network=False)
            if t.strftime("%Y-%m-%d") != day:
                day = t.strftime("%Y-%m-%d")
                logger.info(day)

    def distribute_power(self, load, gen, link, time=0, gen_equals_load=True):
        """Determine load, generation at each bus based on bid zone totals.
        time can be integer index of time series or Timestamp."""

        if type(time) is int:
            time = load.index[time]

        # Generation except wind
        neg_load = pd.DataFrame(0.0, index=self.bidz, columns=["load"])  # Negative load (if generators are missing)
        self.gen["P"] = 0.0
        for b in self.bidz:
            for t in [x for x in self.gen_type if x != "Wind"]:
                ind = self.gen.index[(self.gen.bidz == b) & (self.gen.type == t)]
                available = np.sum(
                    self.gen.loc[ind, "Pmax"]
                )  # available installed capacity per generation type in bidding zone
                if available == 0:
                    neg_load.at[b, "load"] += gen.at[time, (b, t)]  # curtail the non existing generation
                else:
                    share = gen.at[time, (b, t)] / available  # share of bid zone max
                    self.gen.loc[ind, "P"] = (
                        self.gen.loc[ind, "Pmax"] * share
                    )  # distributes total generation among generators
                    if share > 1 and warnings:
                        logger.info(
                            "Not enough %s capacity in %s (%d vs %d MW)"
                            % (t.lower(), b, available, gen.at[time, (b, t)])
                        )

        # Wind
        self.farms["P"] = 0.0
        for b in self.bidz:
            ind = self.farms.index[self.farms.bidz == b]
            available = np.sum(self.farms.loc[ind, "Pmax"])  # available installed wind farm capacity in bidding zone
            if available == 0:
                neg_load.at[b, "load"] += gen.at[time, (b, "Wind")]  # curtail the excess wind generation
            else:
                share = gen.at[time, (b, "Wind")] / available  # share of bid zone max
                self.farms.loc[ind, "P"] = (
                    self.farms.loc[ind, "Pmax"] * share
                )  # distributes total generation among generators
                if share > 1 and warnings:
                    logger.info("Not enough wind capacity in %s (%d vs %d MW)" % (b, available, gen.at[time, (b, "Wind")]))

        # Load including wind (+PV) and negative load
        self.bus["load"] = 0.0
        for b in self.bidz:
            ind = self.bus.index[self.bus.bidz == b]
            bidz_load = (
                load.at[time, b] - neg_load.at[b, "load"]
            )  # total consumption in bidding zone - curtailed generation
            self.bus.loc[ind, "load"] += (
                self.bus.loc[ind, "load_share"] * bidz_load
            )  # distrubuting the net consumption among buses

        # wind as negative load - comment out this section if modelling wind as generator
        for i, row in self.farms.iterrows():
            self.bus.at[int(row.bus), "load"] -= row.P

        # DC (load or negative load at nordic bus)
        self.link["P"] = link.loc[time, :]
        self.link.loc[:,"P"] = self.link.P.fillna(0.0)
        for i, row in self.link.iterrows():
            try:
                self.bus.at[row.bus0, "load"] -= row.P
            except KeyError:
                if row.area0 in self.bidz and warnings:
                    logger.info("No bus found for link %s (%d)" % (row["name"], row.name))
            try:
                self.bus.at[row.bus1, "load"] += row.P
            except KeyError:
                if row.area1 in self.bidz and warnings:
                    logger.info("No bus found for link %s (%d)" % (row["name"], row.name))

        # Adjust generation so it equals load (for DC power flow)
        """To ensure power balance for dc power flow due to discrepancy in the Nordpool database"""
        if gen_equals_load:
            imbal = self.gen.P.sum() - self.bus.load.sum()  # + self.farms.P.sum() #uncomment this part for wind as gen
            for b in self.bidz:
                ratio = np.sum(self.bus.loc[self.bus.bidz == b, "load"]) / self.bus.load.sum()
                self.bus.loc[self.bus.bidz == b, "load"] += (
                    self.bus.loc[self.bus.bidz == b, "load_share"] * ratio * imbal
                )

    def distribute_power2(self, load, gen, link, time=0, gen_equals_load=True, gen_equals_load2=False): #SMR Analysis adjustment
        """Determine load, generation at each bus based on bid zone totals.
        time can be integer index of time series or Timestamp.

        Avoids assigning more power than there is generator capacity for"""

        if type(time) is int:
            time = load.index[time]

        # Generation except wind
        neg_load = pd.DataFrame(0.0, index=self.bidz, columns=["load"])  # Negative load (if generators are missing)
        self.gen["P"] = 0.0
        for b in self.bidz:
            for t in [x for x in self.gen_type if x != "Wind"]:
                ind = self.gen.index[(self.gen.bidz == b) & (self.gen.type == t)]
                available = np.sum(
                    self.gen.loc[ind, "Pmax"]
                )  # available installed capacity per generation type in bidding zone
                if available == 0:
                    neg_load.at[b, "load"] += gen.at[time, (b, t)]  # curtail the non existing generation
                else:
                    share = gen.at[time, (b, t)] / available  # share of bid zone max
                    self.gen.loc[ind, "P"] = (
                        self.gen.loc[ind, "Pmax"] * share
                    )  # distributes total generation among generators
                    if share > 1:
                        self.gen.loc[ind, "P"] = (self.gen.loc[ind, "Pmax"])

                    if share > 1 and warnings:
                        logger.info(
                            "Not enough %s capacity in %s (%d vs %d MW)"
                            % (t.lower(), b, available, gen.at[time, (b, t)])
                        )

        # Wind
        self.farms["P"] = 0.0
        for b in self.bidz:
            ind = self.farms.index[self.farms.bidz == b]
            available = np.sum(self.farms.loc[ind, "Pmax"])  # available installed wind farm capacity in bidding zone
            if available == 0:
                neg_load.at[b, "load"] += gen.at[time, (b, "Wind")]  # curtail the excess wind generation
            else:
                share = gen.at[time, (b, "Wind")] / available  # share of bid zone max
                self.farms.loc[ind, "P"] = (
                    self.farms.loc[ind, "Pmax"] * share
                )  # distributes total generation among generators
                if share > 1 and warnings:
                    logger.info("Not enough wind capacity in %s (%d vs %d MW)" % (b, available, gen.at[time, (b, "Wind")]))

        # Load including wind (+PV) and negative load
        self.bus["load"] = 0.0
        for b in self.bidz:
            ind = self.bus.index[self.bus.bidz == b]
            bidz_load = (
                load.at[time, b] - neg_load.at[b, "load"]
            )  # total consumption in bidding zone - curtailed generation
            self.bus.loc[ind, "load"] += (
                self.bus.loc[ind, "load_share"] * bidz_load
            )  # distrubuting the net consumption among buses

        # wind as negative load - comment out this section if modelling wind as generator
        for i, row in self.farms.iterrows():
            self.bus.at[int(row.bus), "load"] -= row.P

        # DC (load or negative load at nordic bus)
        self.link["P"] = link.loc[time, :]
        self.link.loc[:,"P"] = self.link.P.fillna(0.0)
        for i, row in self.link.iterrows():
            try:
                self.bus.at[row.bus0, "load"] -= row.P
            except KeyError:
                if row.area0 in self.bidz and warnings:
                    logger.info("No bus found for link %s (%d)" % (row["name"], row.name))
            try:
                self.bus.at[row.bus1, "load"] += row.P
            except KeyError:
                if row.area1 in self.bidz and warnings:
                    logger.info("No bus found for link %s (%d)" % (row["name"], row.name))

        # Adjust generation so it equals load (for DC power flow)
        """To ensure power balance for dc power flow due to discrepancy in the Nordpool database"""
        if gen_equals_load:
            imbal = self.gen.P.sum() - self.bus.load.sum()  # + self.farms.P.sum() #uncomment this part for wind as gen
            for b in self.bidz:
                ratio = np.sum(self.bus.loc[self.bus.bidz == b, "load"]) / self.bus.load.sum()
                self.bus.loc[self.bus.bidz == b, "load"] += (
                    self.bus.loc[self.bus.bidz == b, "load_share"] * ratio * imbal
                )
        if gen_equals_load2:
            imbal = self.gen.P.sum() - self.bus.load.sum()  # + self.farms.P.sum() #uncomment this part for wind as gen
            for b in self.bidz:
                ratio = np.sum(self.bus.loc[self.bus.bidz == b, "load"]) / self.bus.load.sum()
                self.bus.loc[self.bus.bidz == b, "load"] += (
                    self.bus.loc[self.bus.bidz == b, "load_share"] * ratio * imbal
                )




    def make_mpc(self, customSlack = [False, 0], slackGreatestPV = False):
        """Make matpower/pypower case (mostly DC parameters for now).
        Safer to use bus_idx etc. to find correct columns for pypower version in question?"""

        bus, line, trafo, gen, farms = (
            self.bus,
            self.line,
            self.trafo,
            self.gen,
            self.farms,
        )
        # gen = pd.concat([gen, farms], sort=False)  # To model wind as generator, uncomment this line
        mpc = {"version": "2", "baseMVA": self.baseMVA}

        # bus
        # bus_i | type | Pd | Qd | Gs | Bs | area | Vm | Va | baseKV | zone | Vmax | Vmin
        mpc["bus"] = np.zeros((len(bus), 13))
        mpc["bus"][:, 0] = bus.index
        #mpc["bus"][:, 1] = [2 if np.sum(gen.Pmax.loc[gen.bus == b]) > 0 else 1 for b in bus.index]  # PV = 2 | PQ = 1

        # SMR Analysis adjustment
        mpc["bus"][:, 1] = [2 if any(gen.Pmax.loc[gen.bus == b] >= 30) and np.sum(gen.Pmax.loc[gen.bus == b]) >= 100 else 1 for b in bus.index]  # PV = 2 | PQ = 1

        # SMR Analysis adjustment
        #Assign Custom Slack Bus in Accordance with Analysis Cases
        if not slackGreatestPV:
            if customSlack[0]:
                #Sweden
                if customSlack[1] == 6118: #Ringhals
                    mpc["bus"][find(mpc["bus"][:, 0] == 6118)[0], 1] = 3  # slack bus, #MadeSelf Ringhals
                elif customSlack[1] == 6364: #Forsmark
                    mpc["bus"][find(mpc["bus"][:, 0] == 6364)[0], 1] = 3  # slack bus, #MadeSelf Forsmark
                elif customSlack[1] == 6729: #Harsprånget
                    mpc["bus"][find(mpc["bus"][:, 0] == 6729)[0], 1] = 3  # slack bus, #MadeSelf Harsprånget
                elif customSlack[1] == 6730: #Ligga
                    mpc["bus"][find(mpc["bus"][:, 0] == 6730)[0], 1] = 3  # slack bus, #MadeSelf Ligga

                elif customSlack[1] == 6377: #Borgvik
                    mpc["bus"][find(mpc["bus"][:, 0] == 6377)[0], 1] = 3  # slack bus, #MadeSelf Borgvik
                elif customSlack[1] == 6142: #Loviseholm
                    mpc["bus"][find(mpc["bus"][:, 0] == 6142)[0], 1] = 3  # slack bus, #MadeSelf Loviseholm

                elif customSlack[1] == 5572: #Baltic Cable
                    mpc["bus"][find(mpc["bus"][:, 0] == 5572)[0], 1] = 3  # slack bus, #MadeSelf Baltic Cable: SE4-Germany interconnection, 450KV

                #Norway
                elif customSlack[1] == 6436: #Kvilldal
                    mpc["bus"][find(mpc["bus"][:, 0] == 6436)[0], 1] = 3  # slack bus, #MadeSelf Kvilldal

                elif customSlack[1] == 6374: #Hasle
                    mpc["bus"][find(mpc["bus"][:, 0] == 6374)[0], 1] = 3  # slack bus, #MadeSelf Hasle

                elif customSlack[1] == 6435:  # North Sea Link
                    mpc["bus"][find(mpc["bus"][:, 0] == 6435)[0], 1] = 3  # slack bus, #MadeSelf North Sea Link
                elif customSlack[1] == 6203:  # NordLink
                    mpc["bus"][find(mpc["bus"][:, 0] == 6203)[0], 1] = 3  # slack bus, #MadeSelf Nord Link

                #Denmark
                elif customSlack[1] == 5530: #Storebaelt
                    mpc["bus"][find(mpc["bus"][:, 0] == 5530)[0], 1] = 3  # slack bus, #MadeSelf Storebaelt: DK2-DK1 interconnection, 400KV

            else:
                mpc["bus"][find(mpc["bus"][:, 1] == 2)[0], 1] = 3  # slack bus


        mpc["bus"][:, 2] = bus.load
        #mpc["bus"][:, 3] = bus.load*0.05  #NB TEST! MADESELF
        mpc["bus"][:, 6] = mult_ind(bus.bidz, self.bidz) + 1  # bid zone index as area
        mpc["bus"][:, 7] = 1  # voltage (pu)
        mpc["bus"][:, 9] = bus.Vbase  # base voltage (kV)
        mpc["bus"][:, 10] = 1  # zone
        mpc["bus"][:, 11] = 0.90  # Vmin
        mpc["bus"][:, 12] = 1.15  # Vmax

        # gen
        # bus | Pg | Qg | Qmax | Qmin | Vg | mBase | status | Pmax | Pmin | Pc1 | Pc2 |
        # Qc1min | Qc1max | Qc2min | Qc2max | ramp_agc | ramp_10 | ramp_30 | ramp_q | apf
        mpc["gen"] = np.zeros((len(gen), 21))
        mpc["gen"][:, 0] = gen.bus
        mpc["gen"][:, 1] = gen.P
        #mpc["gen"][:, 3] = -1000  # Qmin
        #mpc["gen"][:, 4] = 1000  # Qmax

        # SMR Analysis adjustment
        mpc["gen"][:, 3] = 0.75 * gen.Pmax  # Qmax
        mpc["gen"][:, 4] = -0.33 * gen.Pmax  # Qmin

        mpc["gen"][:, 5] = 1  # voltage setpoint
        mpc["gen"][:, 6] = self.baseMVA
        mpc["gen"][:, 7] = 1  # 1 for in-service
        mpc["gen"][:, 8] = gen.Pmax
        mpc["gen"][:, 9] = 0   #SMR Analysis adjustment

        # branch
        br = pd.concat([line, trafo], sort=False)
        # fbus | tbus | r | x | b | rateA | rateB | rateC | ratio | angle | status | angmin | angmax
        mpc["branch"] = np.zeros((len(br), 13))  # creating a zero matrix with no. of branches x 13 elements
        mpc["branch"][:, 0] = br.bus0
        mpc["branch"][:, 1] = br.bus1
        mpc["branch"][:, 2] = br.R
        mpc["branch"][:, 3] = br.X
        mpc["branch"][:, 4] = br.B
        mpc["branch"][:, 5] = br.Cap # SMR Analysis adjustment, RateA
        mpc["branch"][:, 8] = [1 if np.isnan(ug) else 0 for ug in br.ug]  # transformer off nominal turns ratio
        mpc["branch"][:, 10] = 1  # 1 for in-service
        mpc["branch"][:, 11] = -360  # minimum angle difference
        mpc["branch"][:, 12] = 360  # maximum angle difference



        #bus_pmax_mapping = {}
        #for b in bus.index:
        #    bus_pmax_mapping[b] = np.max(gen.Pmax.loc[gen.bus == b]) if np.sum(gen.Pmax.loc[gen.bus == b]) > 0 else 0

        #pv_buses = mpc["bus"][mpc["bus"][:, 1] == 2]  # Extract PV buses
        #sorted_pv_buses = pv_buses[np.argsort([-bus_pmax_mapping[b] for b in pv_buses[:, 0]])]  # Sort PV buses by their maximum Pmax in descending order
        #mpc["bus"][mpc["bus"][:,1] == 2] = sorted_pv_buses  # Replace the original PV buses with the sorted PV buses in mpc["bus"]

        if slackGreatestPV: #SMR Analysis adjustment
            #"""
            # Create a mapping from each bus to the maximum Pmax of generators connected to that bus
            bus_pmax_mapping = {}
            for b in bus.index:
                bus_pmax_mapping[b] = np.max(gen.Pmax.loc[gen.bus == b]) if np.sum(gen.Pmax.loc[gen.bus == b]) > 0 else 0

            pv_buses = mpc["bus"][mpc["bus"][:, 1] == 2] # Extract PV buses
            sorted_pv_buses = pv_buses[np.argsort([-bus_pmax_mapping[b] for b in pv_buses[:, 0]])]  # Sort PV buses by their maximum Pmax in descending order
            #"""

            #mpc["bus"][mpc["bus"][:,1] == 2] = sorted_pv_buses  # Replace the original PV buses with the sorted PV buses in mpc["bus"]
            mpc["bus"][find(mpc["bus"][:,0] == int(sorted_pv_buses[0,0]))[0], 1] = 3  # slack bus



        ## -----  OPF Data  ----- ##  --> Currently not implemented, needs to be fixed
        # generator cost data
        # Model -> 1 - piecewise linear function, 2 - polynomial function
        # 1 | startup | shutdown | n | x1 | y1 | ... | xn | yn
        # 2 | startup | shutdown | n | c(n-1) | ... | c0
        """
           [0]: model, 1 - piecewise linear, 2 - polynomial
           [1]: startup, startup cost in US dollars
           [2]: shutdown, shutdown cost in US dollars
           [3]: N, number of cost coefficients to follow for polynomial cost function, or number of data points for piecewise linear
           [5->]: parameters defining total cost function f(p), units of f and p are $/hr and MW (or MVAr), respectively. 
                  (MODEL = 1) : p0, f0, p1, f1, ..., pn, fn where p0 < p1 < ... < pn 
                                and the cost f(p) is defined by the coordinates (p0,f0), (p1,f1), ..., (pn,fn) 
                                of the end/break-points of the piecewise linear cost function. 
                  (MODEL = 2) : cn, ..., c1, c0 n+1 coefficients of an n-th order polynomial cost function, starting with highest order, 
                                where cost is f(p) = cn*p^n + ... + c1*p + c0
        """

        """ # Uncomment this to run opf
        mpc['gencost'] = np.zeros((len(gen), 7))
        mpc['gencost'][:, 0] = 2 # polynomial function
        mpc['gencost'][:, 3] = 3  # number of polynomial coefficients

        #These values are placeholder, needs to be differentiated and studied 
        HydroGens = gen['type'] == 'Hydro'
        ThermalGens = gen['type'] == 'Thermal'
        NucGens = gen['type'] == 'Nuclear'
        mpc['gencost'][HydroGens, 5] = 10  #Variable O&M Cost
        mpc['gencost'][HydroGens, 6] = 22 #Fixed O&M Cost

        mpc['gencost'][ThermalGens, 5] = 12  #
        mpc['gencost'][ThermalGens, 6] = 12 #

        mpc['gencost'][NucGens, 5] = 4.2  #
        mpc['gencost'][NucGens, 6] = 123 #
        """

        return mpc

    def dcpf(self, time=0, mpc=None, save2network=True):
        """Run DC power flow"""

        if type(time) is int:
            time = self.flow_modelled.index[time]
        if mpc is None:
            mpc = self.make_mpc()
        mpc = rundcpf(
            mpc,
            ppoption(
                VERBOSE=0,
                OUT_SYS_SUM=True,
                #OUT_AREA_SUM=1,
                # OUT_GEN=1,
                OUT_BUS=0,
                OUT_BRANCH=0,

                OUT_ALL_LIM=-1,
                OUT_PG_LIM=0,
                OUT_QG_LIM=0,

                ENFORCE_Q_LIMS=True, #MadeSelf
            ),
        )
        self.solved_mpc.append(mpc)

        # AC exchange between areas
        br = mpc[0]["branch"]
        ac_flow = pd.DataFrame(0.0, index=[time], columns=list(self.flow_modelled))
        bid0 = arr(self.bus.loc[br[:, 0], "bidz"])
        bid1 = arr(self.bus.loc[br[:, 1], "bidz"])
        for n, a0 in enumerate(self.bidz):
            for a1 in self.bidz[n + 1 :]:
                ind0 = (bid0 == a0) & (bid1 == a1)  # find lines between areas
                ind1 = (bid0 == a1) & (bid1 == a0)  # -"- but reverse flow direction
                if np.sum(ind0) + np.sum(ind1) > 0:
                    exch = -np.sum(br[ind0, 13]) + np.sum(br[ind1, 13])
                    ac_flow.loc[time, "%s-%s" % (a0, a1)] = exch
        for i in list(ac_flow):
            self.flow_modelled.at[time, i] = ac_flow.at[time, i]
        if save2network:
            self.mpc2network()  # add parameters to network (flows, voltage angle etc.)

    def acpf(self, time=0, mpc=None, save2network=True, customSlack = [False, 0], slackIsGreatestPV = False): # MadeSelf
        """Run AC power flow"""

        if type(time) is int:
            time = self.flow_modelled.index[time]
        if mpc is None:
            mpc = self.make_mpc(customSlack, slackIsGreatestPV)
        mpc = runpf(
            mpc,
            ppoption(
                VERBOSE=0,

                OUT_ALL=-1,
                OUT_SYS_SUM=True,
                OUT_AREA_SUM=1,
                #OUT_GEN=1,
                OUT_BUS=0,
                OUT_BRANCH=0,

                #Need to be OPF in order to print
                OUT_ALL_LIM=-1,
                OUT_V_LIM=0,
                OUT_LINE_LIM=0,
                OUT_PG_LIM=1,
                OUT_QG_LIM=1,

                ENFORCE_Q_LIMS=True, #MadeSelf
                PF_MAX_IT=30
            ),
        )
        self.solved_mpc.append(mpc)

        # AC exchange between areas
        br = mpc[0]["branch"]
        ac_flow = pd.DataFrame(0.0, index=[time], columns=list(self.flow_modelled))
        bid0 = arr(self.bus.loc[br[:, 0], "bidz"])
        bid1 = arr(self.bus.loc[br[:, 1], "bidz"])
        for n, a0 in enumerate(self.bidz):
            for a1 in self.bidz[n + 1 :]:
                ind0 = (bid0 == a0) & (bid1 == a1)  # find lines between areas
                ind1 = (bid0 == a1) & (bid1 == a0)  # -"- but reverse flow direction
                if np.sum(ind0) + np.sum(ind1) > 0:
                    exch = -np.sum(br[ind0, 13]) + np.sum(br[ind1, 13])
                    ac_flow.loc[time, "%s-%s" % (a0, a1)] = exch
        for i in list(ac_flow):
            self.flow_modelled.at[time, i] = ac_flow.at[time, i]
        if save2network:
            self.mpc2network()  # add parameters to network (flows, voltage angle etc.)


    def oacpf(self, time=0, mpc=None, save2network=True): # MadeSelf
        """Run Optimal AC power flow"""

        if type(time) is int:
            time = self.flow_modelled.index[time]
        if mpc is None:
            mpc = self.make_mpc()
        mpc = runopf(
            mpc,
            ppoption(
                VERBOSE=1,

                OUT_ALL=-1,
                OUT_SYS_SUM=True,
                #OUT_AREA_SUM=1,
                #OUT_GEN=1,
                OUT_BUS=0,
                OUT_BRANCH=0,

                #Need to be OPF in order to print
                OUT_ALL_LIM=-1,
                OUT_V_LIM=0,
                OUT_LINE_LIM=0,
                OUT_PG_LIM=1,
                OUT_QG_LIM=1,

                ENFORCE_Q_LIMS=True, #MadeSelf
            ),
        )
        self.solved_mpc.append(mpc)

        # AC exchange between areas
        #br = mpc[0]["branch"]
        br = mpc["branch"]
        ac_flow = pd.DataFrame(0.0, index=[time], columns=list(self.flow_modelled))
        bid0 = arr(self.bus.loc[br[:, 0], "bidz"])
        bid1 = arr(self.bus.loc[br[:, 1], "bidz"])
        for n, a0 in enumerate(self.bidz):
            for a1 in self.bidz[n + 1 :]:
                ind0 = (bid0 == a0) & (bid1 == a1)  # find lines between areas
                ind1 = (bid0 == a1) & (bid1 == a0)  # -"- but reverse flow direction
                if np.sum(ind0) + np.sum(ind1) > 0:
                    exch = -np.sum(br[ind0, 13]) + np.sum(br[ind1, 13])
                    ac_flow.loc[time, "%s-%s" % (a0, a1)] = exch
        for i in list(ac_flow):
            self.flow_modelled.at[time, i] = ac_flow.at[time, i]

        if save2network:
            self.mpc2network()  # add parameters to network (flows, voltage angle etc.)


    def compare_flows(self, n=None, plot=True):
        """Compare flow_measured with flow_modelled
        Specify n to look at timestep n, otherwise all timesteps
        plot False -> return results dataframe"""

        meas = self.flow_measured
        sim = self.flow_modelled
        if len(meas) == 1:
            n = 0

        if type(n) is int:
            res = pd.DataFrame(index=list(sim), columns=["Measured", "Modelled"])
            res["Measured"] = meas.iloc[n, :].values
            res["Modelled"] = sim.iloc[n, :].values
            if plot:
                res.plot.bar(rot=45, title="AC exchange %s" % sim.index[n])
                plt.show()
        else:
            col = pd.MultiIndex.from_product([list(sim), ["Measured", "Modelled"]])
            res = pd.DataFrame(index=sim.index, columns=col)
            for c in list(sim):
                res.loc[:, (c, "Measured")] = meas[c]
                res.loc[:, (c, "Modelled")] = sim[c]
            if plot:
                fig, ax = plt.subplots(4, 4)
                for n, i in enumerate(list(sim)):
                    res[i].plot(ax=ax[int(n / 4), n % 4], legend=False, title=i)
                    y = ax[int(n / 4), n % 4].get_ylim()
                    ax[int(n / 4), n % 4].set_ylim(min(-1000, y[0]), max(1000, y[1]))
                plt.show()
        if not plot:
            return res

    def calculate_errors(self, n=None):
        """Compare flow_measured with flow_modelled and calculate the error values - mean absolute error, mean absolute
        percentage error and root means square error"""
        "Specify n to look at timestep n, otherwise all returns for all timesteps"

        meas = self.flow_measured
        sim = self.flow_modelled

        if len(meas) == 1:
            n = 0

        if type(n) is int:
            err = pd.DataFrame(index=list(sim), columns=["MAE", "MAPE", "RMSE"])
            err["MAE"] = np.abs(meas.iloc[n, :].values - sim.iloc[n, :].values)
            err["MAPE"] = np.abs((meas.iloc[n, :].values - sim.iloc[n, :].values) / meas.iloc[n, :].values * 100)
            err["RMSE"] = np.sqrt(np.square(meas.iloc[n, :].values - sim.iloc[n, :].values))

        else:
            err = pd.DataFrame(index=list(sim), columns=["MAE", "MAPE", "RMSE"])
            err["MAE"] = np.abs(meas - sim).mean()
            err["MAPE"] = np.abs((meas - sim) / meas * 100).mean()
            err["RMSE"] = np.sqrt(np.square(meas - sim).mean())

        return err

    def save_xlsx(self, file_name):
        """Export data to Excel (different sheets for bus,gen,line...)."""

        writer = pd.ExcelWriter(file_name)
        for df in self.dfs:
            getattr(self, df).to_excel(writer, sheet_name=df)
        writer.close()

    def save_mat(self, path):
        """Export to Matpower format (Matlab)."""
        # TODO Should save a struct instead since this is expected by Matpower
        mpc = self.make_mpc()
        savemat(path, mpc)

    def save_raw(self, file_name):
        """Export to raw format."""
        logger.info("save_raw not implemented yet")

    def pickle(self, path):
        """Pickle whole model."""
        pickle.dump(self, open(path, "wb"))

    def save_shp(self, file_name):
        """Export to GIS shape files.
        Separate files will be saved for buses, lines etc."""
        logger.info("save_shp not implemented yet")

    def plot(self):
        """Make a interactive network plot (using modified SPINE class).
        For more advanced features, see example at top."""
        m = Map(self)
        m.init_plot()
        m.add_topo()
        m.add_legend()
        m.show()

    def simple_plot(self, bus=None, line=None, link=None):
        """Simple plot, possibly highlight certain buses, lines and/or links."""
        data_path = os.path.join("Data", "raw", "map_with_bidz2018.npz")
        temp = np.load(data_path, allow_pickle=True)
        x_map, y_map = temp["x"], temp["y"]
        fig, ax = plt.subplots(1, 1, figsize=[6, 8])
        plt.fill(
            [-1e6, -1e6, 2e6, 2e6, -1e6],
            [5e6, 9e6, 9e6, 5e6, 5e6],
            facecolor=(220.0 / 255, 238.0 / 255, 1),
        )
        for x, y in zip(x_map, y_map):
            plt.fill(x, y, "w")
        for x, y in zip(x_map, y_map):
            plt.plot(x, y, "k", lw=0.5)

        plt.scatter(self.bus.x, self.bus.y, s=3, c="k", zorder=10)
        if bus is not None:
            plt.scatter(self.bus.x.loc[bus], self.bus.y.loc[bus], s=15, c="r", zorder=10)
        for i, row in self.line.iterrows():
            if line is not None and i in line:
                plt.plot(row.x, row.y, c="r", lw=2)
            else:
                plt.plot(row.x, row.y, c="k", lw=0.5)
        for i, row in self.link.iterrows():
            if link is not None and i in line:
                plt.plot(row.x, row.y, c="r", lw=2)
            else:
                plt.plot(row.x, row.y, c="b", lw=0.5)

        plt.xlim([-1.2e5, 1.35e6])
        plt.ylim([5.9e6, 7.95e6])
        fig.subplots_adjust(bottom=0.01, top=0.99, left=0.01, right=0.99)
        ax.tick_params(
            axis="both",
            which="both",
            bottom=False,
            labelbottom=False,
            top=False,
            labeltop=False,
            left=False,
            labelleft=False,
            right=False,
            labelright=False,
        )
        plt.show()

    def find_islands(self):
        """Return island buses."""
        G = nx.Graph()
        for b1, b2 in zip(self.line.bus0, self.line.bus1):
            G.add_edge(b1, b2)
        for b1, b2 in zip(self.trafo.bus0, self.trafo.bus1):
            G.add_edge(b1, b2)
        for b in self.bus.index:
            G.add_node(b)
        SG = [list(c) for c in nx.connected_components(G)]  # sub-graphs
        if len(SG) > 1:
            return [b for s in SG[1:] for b in s]
        else:
            return []

    def balance(self):
        """Calculates the power balance at the last time step"""

        time = self.flow_modelled.index[len(self.flow_modelled.index) - 1]

        # Check balance per area
        bal = pd.DataFrame(0.0, index=self.bidz, columns=["load", "gen", "ac", "balance"])
        for b in self.bidz:
            ind = self.bus.index[self.bus.bidz == b]
            bal.at[b, "load"] = -np.sum(self.bus.loc[ind, "load"])
            ind = self.gen.index[self.gen.bidz == b]
            bal.at[b, "gen"] = np.sum(self.gen.loc[ind, "P"])
            bal.at[b, "ac"] += np.sum(
                np.matrix(self.flow_modelled.loc[time, self.flow_modelled.columns.str.contains(b + "-")])
            )
            bal.at[b, "ac"] -= np.sum(
                np.matrix(self.flow_modelled.loc[time, self.flow_modelled.columns.str.contains("-" + b)])
            )
            # bal.at[b, 'ac'] -= np.sum(np.matrix(ac_flow.loc[:, ac_flow.columns.str.contains('-'+b)]))
        bal["balance"] = np.sum(bal, axis=1)
        logger.info(bal)
        logger.info(bal["balance"].sum())


if __name__ == "__main__":
    m = N490(year=2018)
    self = m
    m.branch_params()
    start = "20181028:00"
    stop = "20181028:15"
    if 0:
        m.time_series(start, stop)
        results = m.compare_flows(plot=False)
    if 0:
        load, gen, link = m.get_measurements(start)
        m.distribute_power(load, gen, link)
        m.dcpf()

    if 0:  # test ac
        load, gen, link = m.get_measurements(start)
        m.distribute_power(load, gen, link, gen_equals_load=False)
        mpc = m.make_mpc()
        mpc = rundcpf(
            mpc,
            ppoption(VERBOSE=0, OUT_ALL=-1, OUT_BUS=0, OUT_ALL_LIM=0, OUT_BRANCH=0),
        )
        # mpc = runpf(mpc,ppoption(VERBOSE=0,OUT_ALL=-1,OUT_BUS=0,OUT_ALL_LIM=0,OUT_BRANCH=0,PF_ALG='NR'))
