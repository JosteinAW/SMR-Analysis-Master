

import pandas as pd
from nordic490 import N490
from network_map import Map
import numpy as np
import networkx as nx
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.colors import LinearSegmentedColormap


class AOperations:
    """Class for analysis operations."""

    def __init__(self, n490, simulationTime = '20180301:08'):
        """"""
        #m = N490(year=2018,set_branch_params=True)
        #self.m = N490(year=2035,set_branch_params=True, seperateCountry=[True, "NO"])
        self.m = n490

        self.simulationTime = simulationTime
        #self.simulationTime = '20180301:08'
        # First time test: '20180120:18'
        # Peak load hour 490: 2018: '20180228:08'
        #Peak load hour Norway 2018: '20180301:08'
        self.load, self.gen, self.link = self.m.get_measurements(self.simulationTime)



    def findTotLoad2018(self, startTime = '20180101:00', stopTime = '20181231:23'):
        """
        This function finds total load and generation info for 2018 from the model's dataset.

        Need to comment out raw = fix_entsoe(raw) in nordic490: .get_measurements() for the code to run,
        since nordic490: fix_entsoe() is not working properly.
        fix_entsoe() is suposed to fix issues related to the Day light saving time shift in october for the entsoe database,
        this part of the code will not affect the load data, only the generation. """

        load2, gen2, link2 = self.m.get_measurements(startTime, stopTime)
        sumLoadNO2018 = load2[["NO1", "NO2", "NO3", "NO4", "NO5"]].sum().sum() /10**6
        sumLoadSE2018 = load2[["SE1", "SE2", "SE3", "SE4"]].sum().sum() /10**6
        sumLoadDK2018 = load2[["DK2"]].sum().sum() /10**6
        sumLoadFI2018 = load2[["FI"]].sum().sum() /10**6


        #Find the date and hour with the maximum total load
        load2['total_load'] = load2.sum(axis=1)
        peakHour = load2['total_load'].idxmax()         # = '20180228:08'
        peakValue = load2.loc[peakHour, 'total_load']   # = 66 678 MW
        #Output the timestamp and the peak load value
        print(f'Date and hour with maximum total load: {peakHour}')
        print(f'Peak load value: {peakValue}')

        #Find the date and hour with the maximum total load in Norway
        load2['Sum_Norway'] = load2[["NO1", "NO2", "NO3", "NO4", "NO5"]].sum(axis=1)
        peakHourNO = load2['Sum_Norway'].idxmax()  # = '20180301:08'
        peakValueNO = load2.loc[peakHourNO, 'total_load']  # = 64 900 MW
        peakValueOnlyNo = load2.loc[peakHourNO, 'Sum_Norway']  # = 24 415 MW
        print(f'Date and hour with maximum total load: {peakHourNO}')
        print(f'Peak load value: {peakValueNO}')
        print(f'Peak load value in only Norway: {peakValueOnlyNo}')


        totLoad2018 = pd.DataFrame(
            [
                {
                    "loadNO": sumLoadNO2018,        # = 135.42 TWh
                    "loadSE": sumLoadSE2018,        # = 138.18 TWh
                    "loadDK": sumLoadDK2018,        # = 13.29  TWh
                    "LoadFI": sumLoadFI2018,        # = 85.77  TWh
                },
            ],
        )

        sumGenNO2018 = gen2[["NO1", "NO2", "NO3", "NO4", "NO5"]].sum().sum() / 10 ** 6
        sumGenNO2018Nuc = gen2[["NO1", "NO2", "NO3", "NO4", "NO5"]].sum()[0] / 10 ** 6
        sumGenNO2018Hyd = gen2[["NO1", "NO2", "NO3", "NO4", "NO5"]].sum()[1] / 10 ** 6
        sumGenNO2018The = gen2[["NO1", "NO2", "NO3", "NO4", "NO5"]].sum()[2] / 10 ** 6
        sumGenNO2018Win = gen2[["NO1", "NO2", "NO3", "NO4", "NO5"]].sum()[3] / 10 ** 6

        sumGenSE2018 = gen2[["SE1", "SE2", "SE3", "SE4"]].sum().sum() / 10 ** 6
        sumGenSE2018Nuc = gen2[["SE1", "SE2", "SE3", "SE4"]].sum()[0] / 10 ** 6
        sumGenSE2018Hyd = gen2[["SE1", "SE2", "SE3", "SE4"]].sum()[1] / 10 ** 6
        sumGenSE2018The = gen2[["SE1", "SE2", "SE3", "SE4"]].sum()[2] / 10 ** 6
        sumGenSE2018Win = gen2[["SE1", "SE2", "SE3", "SE4"]].sum()[3] / 10 ** 6

        sumGenDK2018 = gen2[["DK2"]].sum().sum() / 10 ** 6
        sumGenDK2018Nuc = gen2[["DK2"]].sum()[0] / 10 ** 6
        sumGenDK2018Hyd = gen2[["DK2"]].sum()[1] / 10 ** 6
        sumGenDK2018The = gen2[["DK2"]].sum()[2] / 10 ** 6
        sumGenDK2018Win = gen2[["DK2"]].sum()[3] / 10 ** 6

        sumGenFI2018 = gen2[["FI"]].sum().sum() / 10 ** 6
        sumGenFI2018Nuc = gen2[["FI"]].sum()[0] / 10 ** 6
        sumGenFI2018Hyd = gen2[["FI"]].sum()[1] / 10 ** 6
        sumGenFI2018The = gen2[["FI"]].sum()[2] / 10 ** 6
        sumGenFI2018Win = gen2[["FI"]].sum()[3] / 10 ** 6


        totGen2018 = pd.DataFrame(
            [
                {
                    "loadNO": sumGenNO2018,  # = 123.79 TWh
                    "loadSE": sumGenSE2018,  # = 157.93 TWh
                    "loadDK": sumGenDK2018,  # = 10.93 TWh
                    "LoadFI": sumGenFI2018,  # = 70.52 TWh

                    "loadNONuclear": sumGenNO2018Nuc,   # = 0 TWh
                    "loadNOHydro": sumGenNO2018Hyd,     # = 113.96 TWh
                    "loadNOThermal": sumGenNO2018The,   # = 3.49 TWh
                    "loadNOWind": sumGenNO2018Win,      # = 6.34 TWh

                    "loadSENuclear": sumGenSE2018Nuc,   # = 77.02 TWh
                    "loadSEHydro": sumGenSE2018Hyd,     # = 52.65 TWh
                    "loadSEThermal": sumGenSE2018The,   # = 10.23 TWh
                    "loadSEWind": sumGenSE2018Win,      # = 18 TWh

                    "loadDKNuclear": sumGenDK2018Nuc,   # = 0 TWh
                    "loadDKHydro": sumGenDK2018Hyd,     # = 0 TWh
                    "loadDKThermal": sumGenDK2018The,   # = 5.27 TWh
                    "loadDKWind": sumGenDK2018Win,      #  =  5.66 TWh

                    "loadFINuclear": sumGenFI2018Nuc,   # = 25.37 TWh
                    "loadFIHydro": sumGenFI2018Hyd,     # =  12.52 TWh
                    "loadFIThermal": sumGenFI2018The,   # = 24.41 TWh
                    "loadFIWind": sumGenFI2018Win,      # = 8.22 TWh
                },
            ],
        )
        return totLoad2018, totGen2018, peakHour, peakValue, peakHourNO, peakValueNO, peakValueOnlyNo


    def betweennessCentrality(self, onlyHighVoltage=[False, 380], weighting="none"):
        """This function conducts betweenness centrality on the network"""
        # Create a mapping from bus IDs to indices and vice versa
        bus_id_to_index = {bus_id: idx for idx, bus_id in enumerate(self.m.bus.index)}
        index_to_bus_id = {idx: bus_id for bus_id, idx in bus_id_to_index.items()}

        num_buses = len(self.m.bus)
        adjacency_matrix = np.zeros((num_buses, num_buses))

        # Populate the adjacency matrix with appropriate weights
        for _, line in self.m.line.iterrows():
            from_bus = line.bus0
            to_bus = line.bus1
            length = line.length
            voltage = line.Vbase
            if from_bus in bus_id_to_index and to_bus in bus_id_to_index:
                from_idx = bus_id_to_index[from_bus]
                to_idx = bus_id_to_index[to_bus]
                if onlyHighVoltage[0] and voltage < onlyHighVoltage[1]:
                    continue
                if weighting == "length":
                    weight = length
                elif weighting == "lengthAndVoltage":
                    weight = voltage / length if length != 0 else voltage
                else:
                    weight = 1  # no weighting
                adjacency_matrix[from_idx, to_idx] = weight
                adjacency_matrix[to_idx, from_idx] = weight

        G = nx.Graph(adjacency_matrix)

        betweenness_centrality = nx.betweenness_centrality(G, weight='weight')

        max_centrality_node_index = max(betweenness_centrality, key=betweenness_centrality.get)
        max_centrality_bus_id = index_to_bus_id[max_centrality_node_index]
        max_centrality_value = betweenness_centrality[max_centrality_node_index]

        print(f"Bus ID {max_centrality_bus_id} has the highest betweenness centrality of {max_centrality_value}")
        print("\n")

    def closenessCentrality(self, onlyHighVoltage=[False, 380], weighting="none"):
        """This function conducts closeness centrality on the network"""
        # Create a mapping from bus IDs to indices and vice versa
        bus_id_to_index = {bus_id: idx for idx, bus_id in enumerate(self.m.bus.index)}
        index_to_bus_id = {idx: bus_id for bus_id, idx in bus_id_to_index.items()}

        num_buses = len(self.m.bus)
        adjacency_matrix = np.zeros((num_buses, num_buses))

        # Populate the adjacency matrix with appropriate weights
        for _, line in self.m.line.iterrows():
            from_bus = line.bus0
            to_bus = line.bus1
            length = line.length
            voltage = line.Vbase
            if from_bus in bus_id_to_index and to_bus in bus_id_to_index:
                from_idx = bus_id_to_index[from_bus]
                to_idx = bus_id_to_index[to_bus]
                if onlyHighVoltage[0] and voltage < onlyHighVoltage[1]:
                    continue
                if weighting == "length":
                    weight = length
                elif weighting == "length_voltage":
                    weight = voltage / length if length != 0 else voltage
                else:
                    weight = 1  # no weighting
                adjacency_matrix[from_idx, to_idx] = weight
                adjacency_matrix[to_idx, from_idx] = weight

        G = nx.Graph(adjacency_matrix)

        closeness_centrality = nx.closeness_centrality(G, distance='weight')

        max_centrality_node_index = max(closeness_centrality, key=closeness_centrality.get)
        max_centrality_bus_id = index_to_bus_id[max_centrality_node_index]
        max_centrality_value = closeness_centrality[max_centrality_node_index]

        print(f"Bus ID {max_centrality_bus_id} has the highest closeness centrality of {max_centrality_value}")
        print("\n")

    def eigenvectorCentrality(self, onlyHighVoltage=[False, 380], weighting="none"):
        """This function conducts eigenvector centrality on the network"""
        # Create a mapping from bus IDs to indices and vice versa
        bus_id_to_index = {bus_id: idx for idx, bus_id in enumerate(self.m.bus.index)}
        index_to_bus_id = {idx: bus_id for bus_id, idx in bus_id_to_index.items()}

        num_buses = len(self.m.bus)
        adjacency_matrix = np.zeros((num_buses, num_buses))

        # Populate the adjacency matrix with appropriate weights
        for _, line in self.m.line.iterrows():
            from_bus = line.bus0
            to_bus = line.bus1
            length = line.length
            voltage = line.Vbase
            if from_bus in bus_id_to_index and to_bus in bus_id_to_index:
                from_idx = bus_id_to_index[from_bus]
                to_idx = bus_id_to_index[to_bus]
                if onlyHighVoltage[0] and voltage < onlyHighVoltage[1]:
                    continue
                if weighting == "length":
                    weight = length
                elif weighting == "length_voltage":
                    weight = voltage / length if length != 0 else voltage
                else:
                    weight = 1  # no weighting
                adjacency_matrix[from_idx, to_idx] = weight
                adjacency_matrix[to_idx, from_idx] = weight

        G = nx.Graph(adjacency_matrix)

        eigenvector_centrality = nx.eigenvector_centrality_numpy(G, weight='weight')

        max_centrality_node_index = max(eigenvector_centrality, key=eigenvector_centrality.get)
        max_centrality_bus_id = index_to_bus_id[max_centrality_node_index]
        max_centrality_value = eigenvector_centrality[max_centrality_node_index]

        print(f"Bus ID {max_centrality_bus_id} has the highest eigenvector centrality of {max_centrality_value}")
        print("\n")

    def pageRankCentrality(self, onlyHighVoltage=[False, 380], weighting="none"):
        """This function conducts pagerank centrality on the network"""
        # Create a mapping from bus IDs to indices and vice versa
        bus_id_to_index = {bus_id: idx for idx, bus_id in enumerate(self.m.bus.index)}
        index_to_bus_id = {idx: bus_id for bus_id, idx in bus_id_to_index.items()}

        num_buses = len(self.m.bus)
        adjacency_matrix = np.zeros((num_buses, num_buses))

        # Populate the adjacency matrix with appropriate weights
        for _, line in self.m.line.iterrows():
            from_bus = line.bus0
            to_bus = line.bus1
            length = line.length
            voltage = line.Vbase
            if from_bus in bus_id_to_index and to_bus in bus_id_to_index:
                from_idx = bus_id_to_index[from_bus]
                to_idx = bus_id_to_index[to_bus]
                if onlyHighVoltage[0] and voltage < onlyHighVoltage[1]:
                    continue
                if weighting == "length":
                    weight = length
                elif weighting == "length_voltage":
                    weight = voltage / length if length != 0 else voltage
                else:
                    weight = 1  # no weighting
                adjacency_matrix[from_idx, to_idx] = weight
                adjacency_matrix[to_idx, from_idx] = weight

        G = nx.Graph(adjacency_matrix)

        pagerank_centrality = nx.pagerank(G, weight='weight')

        max_centrality_node_index = max(pagerank_centrality, key=pagerank_centrality.get)
        max_centrality_bus_id = index_to_bus_id[max_centrality_node_index]
        max_centrality_value = pagerank_centrality[max_centrality_node_index]

        print(f"Bus ID {max_centrality_bus_id} has the highest PageRank centrality of {max_centrality_value}")
        print("\n")

    def nameUnknownBusses(self):
        """This function names key unnamed busses."""
        self.m.bus.loc[6475, "name"] = "Follo"
        self.m.bus.loc[6476, "name"] = "Tegneby Nord"
        self.m.bus.loc[6477, "name"] = "Tegneby"
        self.m.bus.loc[6479, "name"] = "Hof"
        self.m.bus.loc[6480, "name"] = "Filtvet"

        self.m.bus.loc[6463, "name"] = "Tveiten"
        self.m.bus.loc[6464, "name"] = "Flesaker"
        self.m.bus.loc[6467, "name"] = "Rød LV"
        self.m.bus.loc[6468, "name"] = "Rød HV"

    def fixkeyLines(self, year = 2021):
        """This function fixes key overloaded lines within Norway, at the intitial state of the system, in accordance with NVE Atlas."""
        line1 = 1210 #Vemork - Drammen
        self.m.line.loc[line1, "bus0"] = 6461
        self.m.line.loc[line1, "length"] = 81871.3543

        self.m.line.at[line1, "lat"] = [self.m.bus.loc[6461, "lat"], self.m.bus.loc[6464, "lat"]]
        self.m.line.at[line1, "lon"] = [self.m.bus.loc[6461, "lon"], self.m.bus.loc[6464, "lon"]]

        self.m.line.at[line1, "x"] = [self.m.bus.loc[6461, "x"], self.m.bus.loc[6464, "x"]]
        self.m.line.at[line1, "y"] = [self.m.bus.loc[6461, "y"], self.m.bus.loc[6464, "y"]]

        line2 = 1314 #Såheim - Vemork
        #self.m.line.loc[line2, "Vbase"] = 132.0
        self.m.line.loc[line2, "Vbase"] = 380.0

        #New Splitted Lines
        self.m.line.drop(1318, inplace=True) #Line 1: Sogndal - Ålsesund
        self.m.line.drop(1323, inplace=True) # Line 2: Kvildal - Sylling
        splittedLines1 = pd.DataFrame(
            [
                {
                    "area0": "NO3",
                    "area1": "NO3",
                    "bus0": 6618,
                    "bus1": 6607,
                    "length": self.m.line.loc[1165, "length"],
                    "circuits": 1,
                    "Vbase": 380,
                    "ug": False,
                    "uc": 0,
                    "lat": [self.m.bus.loc[6618, "lat"], 61.747131, 62.428532, 62.477862710769],
                    "lon": [self.m.bus.loc[6618, "lon"], 5.364075, 7.03262300000001, 7.03399124581907],
                    "x": [self.m.bus.loc[6618, "x"], -7550.85211375, 89323.82261942, 90072.17846929],
                    "y": [self.m.bus.loc[6618, "y"], 6883734.76339466, 6947289.9580555, 6952746.52660628],
                    "source": "Pypsa 2019-09-04 + NVE Atlas",
                    "info": {},  # Åskara - Ålesund
                },
                {
                    "area0": "NO3",
                    "area1": "NO5",
                    "bus0": 6618,
                    "bus1": 6407,
                    "length": (self.m.line.loc[1337, "length"] + self.m.line.loc[1181, "length"]),
                    "circuits": 1,
                    "Vbase": 380,
                    "ug": False,
                    "uc": 0,
                    "lat": [61.2068619583834, 61.253065, 61.280793, 61.642945, self.m.bus.loc[6618, "lat"]],
                    "lon": [7.33844017316839, 7.02987699999999, 6.01089500000001, 5.37231400000001, self.m.bus.loc[6618, "lon"]],
                    "x": [88975.41373265, 73106.67779042, 19183.27634399, -8838.96087067, self.m.bus.loc[6618, "x"]],
                    "y": [6809965.01266608, 6817069.10697363, 6827241.32834575, 6872155.32529231, self.m.bus.loc[6618, "y"]],
                    "source": "Pypsa 2019-09-04 + NVE Atlas",
                    "info": {},  # Sogndal - Åskara
                },
            ],
            index=[8886, 8887],
        )
        self.m.line = self.m.line._append(splittedLines1)

        splittedLines2 = pd.DataFrame(
            [
                {
                    "area0": "NO2",
                    "area1": "NO1",
                    "bus0": 6462,
                    "bus1": 6466,
                    "length": 98311.7778,
                    "circuits": 1,
                    "Vbase": 380,
                    "ug": False,
                    "uc": 0,
                    "lat": [self.m.bus.loc[6462, "lat"], 59.701014, 59.777139, 59.817209, 59.806851, 59.749477, 59.770918, 59.8866571674775],
                    "lon": [self.m.bus.loc[6462, "lon"], 9.65148899999999, 9.706421, 9.81216400000001, 9.95498699999999, 10.019531, 10.211792, 10.2885545953851],
                    "x": [self.m.bus.loc[6462, "x"], 199199.65457739, 202961.69685775, 209236.57793253, 217143.13216376, 220277.11814869, 231235.08341379, 236455.80567838],
                    "y": [self.m.bus.loc[6462, "y"], 6630249.84540577, 6638461.4359333, 6642445.1168709, 6640675.06765661, 6634023.6022243, 6635611.06198939, 6648169.74105923],
                    "source": "Pypsa 2019-09-04 + NVE Atlas",
                    "info": {}, # Såheim - Sylling
                },
                #{
                #    "area0": "NO2",
                #    "area1": "NO2",
                #    "bus0": 6436,
                #    "bus1": 6462,
                #    "length": (92182.3004 + 37633.4135),
                #    "circuits": 1,
                #    "Vbase": 380,
                #    "ug": False,
                #    "uc": 0,
                #    "lat": [59.5240340462335, 59.681608, 59.728023, 59.87033, self.m.bus.loc[6462, "lat"]],
                #    "lon": [6.99311328340451, 7.30041499999999, 7.829132, 8.64898700000001, self.m.bus.loc[6462, "lon"]],
                #    "x": [ 47713.92389763, 67057.43929477, 97266.52255361, 144731.95732749, self.m.bus.loc[6462, "x"]],
                #    "y": [6625709.82227043, 6641122.27311971, 6642930.9715729, 6654026.33762153, self.m.bus.loc[6462, "y"]],
                #    "source": "Pypsa 2019-09-04 + NVE Atlas",
                #    "info": {}, #Kvildal - Såheim
                #},
                {
                    "area0": "NO2",
                    "area1": "NO2",
                    "bus0": 6436,
                    "bus1": 6461,
                    "length": (92182.3004 + 37633.4135-self.m.line.loc[1314, "length"]),
                    "circuits": 1,
                    "Vbase": 380,
                    "ug": False,
                    "uc": 0,
                    "lat": [59.5240340462335, 59.681608, 59.728023, self.m.bus.loc[6461, "lat"]],
                    "lon": [6.99311328340451, 7.30041499999999, 7.829132,
                            self.m.bus.loc[6461, "lon"]],
                    "x": [47713.92389763, 67057.43929477, 97266.52255361, self.m.bus.loc[6461, "x"]],
                    "y": [6625709.82227043, 6641122.27311971, 6642930.9715729,
                          self.m.bus.loc[6461, "y"]],
                    "source": "Pypsa 2019-09-04 + NVE Atlas",
                    "info": {},  # Kvildal - Vemork
                }
            ],
            index=[8888, 8889],
        )
        self.m.line = self.m.line._append(splittedLines2)
        self.m.branch_params()

        if year == 2030:

            #Not implemented because of dataframe formating issues with the new Surna bus 6620
            """
            newbus = pd.DataFrame(
                [
                    {
                        "name": "Surna",
                        "bidz": "NO3",
                        "Vbase": 380,
                        "uc": 0,
                        "lat": 63.202068,
                        "lon": 9.79156500000001,
                        "x": 238219.01803986,
                        "y": 7018734.3116326,
                        "country": "NO",
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                        "load_share": 0.0,
                    },
                ],
                index=[6620],
            )
            self.m.bus = self.m.bus._append(newbus)

            self.m.line.drop(1175, inplace=True)  # Line 3: Trondheim (Orkanger) - Aure
            self.m.line.drop(1293, inplace=True)  # Line 4: Trondheim 2 - Aure
            splittedLines3 = pd.DataFrame(
                [
                    {
                        "area0": "NO3",
                        "area1": "NO3",
                        "bus0": 6604,
                        "bus1": 6620,
                        "length": 49302.6329,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6604, "lat"], 63.021959, self.m.bus.loc[6620, "lat"]],
                        "lon": [self.m.bus.loc[6604, "lon"], 8.897552, self.m.bus.loc[6620, "lon"]],
                        "x": [self.m.bus.loc[6604, "x"], 191471.76503967, self.m.bus.loc[6620, "x"]],
                        "y": [self.m.bus.loc[6604, "y"], 7002697.80678609, self.m.bus.loc[6620, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},  # Trondheim(Orkanger) - Surna
                    },
                    {
                        "area0": "NO3",
                        "area1": "NO5",
                        "bus0": 6620,
                        "bus1": 6608,
                        "length": 51226.5387,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6620, "lat"], self.m.bus.loc[6608, "lat"]],
                        "lon": [self.m.bus.loc[6620, "lon"], self.m.bus.loc[6608, "lon"]],
                        "x": [self.m.bus.loc[6620, "x"], 188000, self.m.bus.loc[6608, "x"]],
                        "y": [self.m.bus.loc[6620, "y"], 6983000, self.m.bus.loc[6608, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},  # Surna - Aure
                    },
                    {
                        "area0": "NO3",
                        "area1": "NO3",
                        "bus0": 6602,
                        "bus1": 6620,
                        "length": 83470.5447,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6602, "lat"], 63.325632, self.m.bus.loc[6620, "lat"]],
                        "lon": [self.m.bus.loc[6602, "lon"], 9.986572, self.m.bus.loc[6620, "lon"]],
                        "x": [self.m.bus.loc[6602, "x"], 249081.25711535, self.m.bus.loc[6620, "x"]],
                        "y": [self.m.bus.loc[6602, "y"], 7031689.27604741, self.m.bus.loc[6620, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},  # Trondheim 2 - Surna
                    },
                    {
                        "area0": "NO3",
                        "area1": "NO5",
                        "bus0": 6620,
                        "bus1": 6608,
                        "length": 47516.3989,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6620, "lat"], self.m.bus.loc[6608, "lat"]],
                        "lon": [self.m.bus.loc[6620, "lon"], self.m.bus.loc[6608, "lon"]],
                        "x": [self.m.bus.loc[6620, "x"], 175000, self.m.bus.loc[6608, "x"]],
                        "y": [self.m.bus.loc[6620, "y"], 6983000, self.m.bus.loc[6608, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},  # Surna - Aure 2
                    },
                ],
                index=[8882, 8883, 8884, 8885],
            )
            self.m.line = self.m.line._append(splittedLines3)
            """

            self.m.line.drop(1274, inplace=True)  # Line 5: Hasle - Rød (Horten)
            splittedLines4 = pd.DataFrame(
                [
                    {
                        "area0": "NO3",
                        "area1": "NO3",
                        "bus0": 6375,
                        "bus1": 6463,
                        "length": 45900,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6375, "lat"], 59.356996, self.m.bus.loc[6463, "lat"]],
                        "lon": [self.m.bus.loc[6375, "lon"], 10.732269, self.m.bus.loc[6463, "lon"]],
                        "x": [self.m.bus.loc[6375, "x"], 257459.68522723, self.m.bus.loc[6463, "x"]],
                        "y": [self.m.bus.loc[6375, "y"], 6587581.86446494, self.m.bus.loc[6463, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},  # Halse - Horten
                    },
                ],
                index = [8881],
            )
            self.m.line = self.m.line._append(splittedLines4)
            self.m.branch_params()



    def upgradeLines(self, upgradeYear = 2021):
        """This function upgrades the network within Norway from the models state in 2017/2018, to either 2021, 2030, or 2045
         in accordance with Statnett's Nettutviklingsplan 2021."""
        if upgradeYear == 2021:
            upgrades2021 = [1313, 1232, 1237, 1238, 1230, 1233, 1234, 1235, 1227, 1342, 1212, 1307, 1173, 1288, 1289, 1172, 1333, 1169]
            connectedBusses = []

            for line in upgrades2021:
                self.m.line.loc[line, "Vbase"] = 380
                connectedBusses.append(self.m.line.loc[line, "bus0"])

            newLines = pd.DataFrame(
                [
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6725,
                        "bus1": 6724,
                        "length": 50714.8423,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [68.158786, 68.517173],
                        "lon": [17.288361, 17.579498],
                        "x": [594990.265443, 610600, 615000, 605398.027109],
                        "y": [7562328.757993, 7571000, 7590000, 7602734.492435],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6724,
                        "bus1": 6752,
                        "length": 103454.1928,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [68.517173, 69.183065],
                        "lon": [17.579498, 19.24942],
                        "x": [605398.027109, 625100, 665000, 668422.501282],
                        "y": [7602734.492435, 7610000, 7660300, 7680616.219424],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6752,
                        "bus1": 6747,
                        "length": (90323.0529 + 122518.2136),
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [69.183065, 69.935012],
                        "lon": [19.24942, 23.410492],
                        "x": [668422.501282, 765500, 821153.177687],
                        "y": [7680616.219424, 7760000, 7780815.596067],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6747,
                        "bus1": 6746,
                        "length": 66002.682058,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [69.935012, 70.363091],
                        "lon": [23.410492, 24.613495],
                        "x": [821153.177687, 817000, 845000, 859255.88589],
                        "y": [7780815.596067, 7791500, 7830000, 7834833.210918],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                ],
                index=[9996, 9997, 9998, 9999],
            )
            self.m.line = self.m.line._append(newLines)

            for line in [9996, 9997, 9998, 9999]:
                connectedBusses.append(self.m.line.loc[line, "bus0"])

            for bus in connectedBusses:
                self.m.bus.loc[bus, "Vbase"] = 380

            self.m.branch_params()

        elif upgradeYear == 2030:
            #upgrades2021 = [1313, 1232, 1237, 1238, 1230, 1233, 1234, 1235, 1227, 1342, 1212, 1307, 1173, 1288, 1289, 1172, 1333, 1169]
            upgrades2030 = [1313, 1242, 1232, 1237, 1238, 1230, 1233, 1234, 1235, 1227, 1342, 1212, 1307, 1173, 1288, 1289, 1172, 1333, 1169, 1231, 1215, 1206, 1207, 1195, 1298, 1188, 1186, 1295, 1294, 6488, 1185, 1194, 1175, 1292, 1174, 1315, 1324, 1222]
            connectedBusses = []

            for line in upgrades2030:
                self.m.line.loc[line, "Vbase"] = 380
                connectedBusses.append(self.m.line.loc[line, "bus0"])

            newLines = pd.DataFrame(
                [
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6725,
                        "bus1": 6724,
                        "length": 50714.8423,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [68.158786, 68.517173],
                        "lon": [17.288361, 17.579498],
                        "x": [594990.265443, 610600, 615000, 605398.027109],
                        "y": [7562328.757993, 7571000, 7590000, 7602734.492435],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6724,
                        "bus1": 6757,
                        "length": self.m.line.loc[1320, "length"],
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [68.517173, self.m.bus.loc[6751, "lat"]],
                        "lon": [17.579498, self.m.bus.loc[6751, "lon"]],
                        "x": [605398.027109, 625100, 653000, self.m.bus.loc[6757, "x"]],
                        "y": [7602734.492435 , 7610000, 7640300, self.m.bus.loc[6757, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6757,
                        "bus1": 6752,
                        "length": self.m.line.loc[1243, "length"],
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6757, "lat"], 69.183065],
                        "lon": [self.m.bus.loc[6757, "lon"], 19.24942],
                        "x": [self.m.bus.loc[6757, "x"], 667000, 668422.501282],
                        "y": [self.m.bus.loc[6757, "y"], 7667300, 7680616.219424],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6752,
                        "bus1": 6751,
                        "length": 90323.0529,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [69.183065, self.m.bus.loc[6751, "lat"]],
                        "lon": [19.24942, self.m.bus.loc[6751, "lon"]],
                        "x": [668422.501282, self.m.bus.loc[6751, "x"]],
                        "y": [7680616.219424, self.m.bus.loc[6751, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6752,
                        "bus1": 6751,
                        "length": 90323.0529,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [69.183065, self.m.bus.loc[6751, "lat"]],
                        "lon": [19.24942, self.m.bus.loc[6751, "lon"]],
                        "x": [668422.501282, 686000, self.m.bus.loc[6751, "x"]],
                        "y": [7680616.219424, 7705000, self.m.bus.loc[6751, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6751,
                        "bus1": 6747,
                        "length": 122518.2136,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6751, "lat"], 69.935012],
                        "lon": [self.m.bus.loc[6751, "lon"], 23.410492],
                        "x": [self.m.bus.loc[6751, "x"], 765500, 821153.177687],
                        "y": [self.m.bus.loc[6751, "y"], 7760000, 7780815.596067],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6751,
                        "bus1": 6747,
                        "length": 122518.2136,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6751, "lat"], 69.935012],
                        "lon": [self.m.bus.loc[6751, "lon"], 23.410492],
                        "x": [self.m.bus.loc[6751, "x"], 785500, 821153.177687],
                        "y": [self.m.bus.loc[6751, "y"], 7740000, 7780815.596067],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6747,
                        "bus1": 6746,
                        "length": 66002.682058,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [69.935012, 70.363091],
                        "lon": [23.410492, 24.613495],
                        "x": [821153.177687, 817000, 845000, 859255.88589],
                        "y": [7780815.596067, 7791500, 7830000, 7834833.210918],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6747,
                        "bus1": 6746,
                        "length": 66002.682058,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [69.935012, 70.363091],
                        "lon": [23.410492, 24.613495],
                        "x": [821153.177687, 810000, 838000, 859255.88589],
                        "y": [7780815.596067, 7791500, 7830000, 7834833.210918],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6746,
                        "bus1": 6748,
                        "length": self.m.line.loc[1159,"length"],
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6746, "lat"], self.m.bus.loc[6748, "lat"]],
                        "lon": [self.m.bus.loc[6746, "lon"], self.m.bus.loc[6748, "lon"]],
                        "x": [self.m.bus.loc[6746, "x"], 867000, 886000, self.m.bus.loc[6748, "x"]],
                        "y": [self.m.bus.loc[6746, "y"], 7834000, 7800000, self.m.bus.loc[6748, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6745,
                        "bus1": 6748,
                        "length": self.m.line.loc[1157, "length"],
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6745, "lat"], self.m.bus.loc[6748, "lat"]],
                        "lon": [self.m.bus.loc[6745, "lon"], self.m.bus.loc[6748, "lon"]],
                        "x": [self.m.bus.loc[6745, "x"], 920000, 889000, self.m.bus.loc[6748, "x"]],
                        "y": [self.m.bus.loc[6745, "y"], 7838000, 7800000, self.m.bus.loc[6748, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6738,
                        "bus1": 6745,
                        "length": self.m.line.loc[1279, "length"],
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6738, "lat"], self.m.bus.loc[6745, "lat"]],
                        "lon": [self.m.bus.loc[6738, "lon"], self.m.bus.loc[6745, "lon"]],
                        "x": [self.m.bus.loc[6738, "x"], 998000, 941000, self.m.bus.loc[6745, "x"]],
                        "y": [self.m.bus.loc[6738, "y"], 7845000, 7845000, self.m.bus.loc[6745, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO2",
                        "area1": "NO2",
                        "bus0": 6200,
                        "bus1": 6448,
                        "length": 66628.8047,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6200, "lat"], self.m.bus.loc[6448, "lat"]],
                        "lon": [self.m.bus.loc[6200, "lon"], self.m.bus.loc[6448, "lon"]],
                        "x": [self.m.bus.loc[6200, "x"], self.m.bus.loc[6448, "x"]],
                        "y": [self.m.bus.loc[6200, "y"], self.m.bus.loc[6448, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO2",
                        "area1": "NO2",
                        "bus0": 6492,
                        "bus1": 6433,
                        "length": 83920,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6492, "lat"], self.m.bus.loc[6433, "lat"]],
                        "lon": [self.m.bus.loc[6492, "lon"], self.m.bus.loc[6433, "lon"]],
                        "x": [self.m.bus.loc[6492, "x"], -38000, self.m.bus.loc[6433, "x"]],
                        "y": [self.m.bus.loc[6492, "y"], 6635000, self.m.bus.loc[6433, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas + Google Maps",
                        "info": {},
                    },
                    {
                        "area0": "NO5",
                        "area1": "NO5",
                        "bus0": 6493,
                        "bus1": 6484,
                        "length": (self.m.line.loc[1190,"length"] + self.m.line.loc[1192,"length"] + self.m.line.loc[1296,"length"]),
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6493, "lat"], self.m.bus.loc[6484, "lat"]],
                        "lon": [self.m.bus.loc[6493, "lon"], self.m.bus.loc[6484, "lon"]],
                        "x": [self.m.bus.loc[6493, "x"], self.m.bus.loc[6484, "x"]],
                        "y": [self.m.bus.loc[6493, "y"], self.m.bus.loc[6484, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO5",
                        "area1": "NO5",
                        "bus0": 6493,
                        "bus1": 6413,
                        "length": (11888.7894 + 27337.4532 + 28697.5132 + 4752.0554),
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6493, "lat"], self.m.bus.loc[6413, "lat"]],
                        "lon": [self.m.bus.loc[6493, "lon"], self.m.bus.loc[6413, "lon"]],
                        "x": [self.m.bus.loc[6493, "x"], -38500, -11000, self.m.bus.loc[6413, "x"]],
                        "y": [self.m.bus.loc[6493, "y"], 6775000, 6783000, self.m.bus.loc[6413, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO2",
                        "area1": "NO2",
                        "bus0": 6210,
                        "bus1": 6455,
                        "length": self.m.line.loc[1232, "length"],
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6210, "lat"], self.m.bus.loc[6455, "lat"]],
                        "lon": [self.m.bus.loc[6210, "lon"], self.m.bus.loc[6455, "lon"]],
                        "x": [self.m.bus.loc[6210, "x"], 148000, 195000, self.m.bus.loc[6455, "x"]],
                        "y": [self.m.bus.loc[6210, "y"], 6510000, 6560000, self.m.bus.loc[6455, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO2",
                        "area1": "NO2",
                        "bus0": 6455,
                        "bus1": 6463,
                        "length": 46760,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6455, "lat"], self.m.bus.loc[6463, "lat"]],
                        "lon": [self.m.bus.loc[6455, "lon"], self.m.bus.loc[6463, "lon"]],
                        "x": [self.m.bus.loc[6455, "x"], self.m.bus.loc[6463, "x"]],
                        "y": [self.m.bus.loc[6455, "y"], self.m.bus.loc[6463, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas + Google Maps",
                        "info": {},
                    },
                    {
                        "area0": "NO3",
                        "area1": "NO3",
                        "bus0": 6609,
                        "bus1": 6617,
                        "length": (43190.5403 + 24746.9837 + 25145.7712),
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6609, "lat"], self.m.bus.loc[6617, "lat"]],
                        "lon": [self.m.bus.loc[6609, "lon"], self.m.bus.loc[6617, "lon"]],
                        "x": [self.m.bus.loc[6609, "x"], 129000, self.m.bus.loc[6617, "x"]],
                        "y": [self.m.bus.loc[6609, "y"], 6973000, self.m.bus.loc[6617, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO3",
                        "area1": "NO3",
                        "bus0": 6682,
                        "bus1": 6609,
                        "length": (47516.3989 + 63649.3912 + 67100 + 37799.0132 + 82057.4203),
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6682, "lat"], self.m.bus.loc[6609, "lat"]],
                        "lon": [self.m.bus.loc[6682, "lon"], self.m.bus.loc[6609, "lon"]],
                        "x": [self.m.bus.loc[6682, "x"], 292000, 270000, 240000, 184816.98256803, self.m.bus.loc[6609, "x"]],
                        "y": [self.m.bus.loc[6682, "y"], 7140000, 7093000, 7045000, 7010453.31545183, self.m.bus.loc[6609, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas + Google Maps",
                        "info": {},
                    },
                ],
                index=[9980, 9981, 9982, 9983, 9984, 9985, 9986, 9987, 9988, 9989, 9990, 9991, 9992, 9993, 9994, 9995, 9996, 9997, 9998, 9999],
            )

            self.m.line = self.m.line._append(newLines)

            for line in [9980, 9981, 9982, 9983, 9984, 9985, 9986, 9987, 9988, 9989, 9990, 9991, 9992, 9993, 9994, 9995, 9996, 9997, 9998, 9999]:
                connectedBusses.append(self.m.line.loc[line, "bus0"])

            for bus in connectedBusses:
                self.m.bus.loc[bus, "Vbase"] = 380

            self.m.branch_params()

        elif upgradeYear == 2045:
            # upgrades2021 = [1313, 1232, 1237, 1238, 1230, 1233, 1234, 1235, 1227, 1342, 1212, 1307, 1173, 1288, 1289, 1172, 1333, 1169]
            #upgrades2030 = [1313, 1242, 1232, 1237, 1238, 1230, 1233, 1234, 1235, 1227, 1342, 1212, 1307, 1173, 1288, 1289,
            #                1172, 1333, 1169, 1231, 1215, 1206, 1207, 1195, 1298, 1188, 1186, 1295, 1294, 6488, 1185, 1194,
            #                1175, 1292, 1174, 1315, 1324, 1222]
            upgrades2045 = [1313, 1242, 1232, 1237, 1238, 1230, 1233, 1234, 1235, 1227, 1342, 1212, 1307, 1173, 1288,
                            1289, 1172, 1333, 1169, 1231, 1215, 1206, 1207, 1195, 1298, 1188, 1186, 1295, 1294, 6488,
                            1185, 1194, 1175, 1292, 1174, 1315, 1324, 1222,
                            1287, 1168, 1290, 1291, 6798, 1341, 1184, 1200, 1339, 1338, 1240, 1223, 1326, 1220, 1301,
                            1199, 1198, 1189, 9665, 9664, 9501, 1177, 1296, 1347, 1190, 1297, 1192, 1239, 1216, 1305,
                            1304, 1196, 1299, 1205, 1226, 1329, 1218, 1225, 1241, 1236, 1309, 1310, 1344, 1202, 1345,
                            1201, 1210, 1217, 1316, 1346, 1213, 1208, 1211, 1209]
            connectedBusses = []
            doubled2045 = [1245, 1247, 1248, 1249, 1250, 1172, 1209]
            decomissioned2045 = [1171]

            for line in upgrades2045:
                self.m.line.loc[line, "Vbase"] = 380
                connectedBusses.append(self.m.line.loc[line, "bus0"])

            for line in doubled2045:
                self.m.line.loc[line, "circuits"] = 2

            for line in decomissioned2045:
                self.m.line.drop(line, inplace=True)

            newLines = pd.DataFrame(
                [
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6725,
                        "bus1": 6724,
                        "length": 50714.8423,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [68.158786, 68.517173],
                        "lon": [17.288361, 17.579498],
                        "x": [594990.265443, 610600, 615000, 605398.027109],
                        "y": [7562328.757993, 7571000, 7590000, 7602734.492435],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6724,
                        "bus1": 6757,
                        "length": self.m.line.loc[1320, "length"],
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [68.517173, self.m.bus.loc[6751, "lat"]],
                        "lon": [17.579498, self.m.bus.loc[6751, "lon"]],
                        "x": [605398.027109, 625100, 653000, self.m.bus.loc[6757, "x"]],
                        "y": [7602734.492435, 7610000, 7640300, self.m.bus.loc[6757, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6757,
                        "bus1": 6752,
                        "length": self.m.line.loc[1243, "length"],
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6757, "lat"], 69.183065],
                        "lon": [self.m.bus.loc[6757, "lon"], 19.24942],
                        "x": [self.m.bus.loc[6757, "x"], 667000, 668422.501282],
                        "y": [self.m.bus.loc[6757, "y"], 7667300, 7680616.219424],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6752,
                        "bus1": 6751,
                        "length": 90323.0529,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [69.183065, self.m.bus.loc[6751, "lat"]],
                        "lon": [19.24942, self.m.bus.loc[6751, "lon"]],
                        "x": [668422.501282, self.m.bus.loc[6751, "x"]],
                        "y": [7680616.219424, self.m.bus.loc[6751, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6752,
                        "bus1": 6751,
                        "length": 90323.0529,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [69.183065, self.m.bus.loc[6751, "lat"]],
                        "lon": [19.24942, self.m.bus.loc[6751, "lon"]],
                        "x": [668422.501282, 686000, self.m.bus.loc[6751, "x"]],
                        "y": [7680616.219424, 7705000, self.m.bus.loc[6751, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6751,
                        "bus1": 6747,
                        "length": 122518.2136,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6751, "lat"], 69.935012],
                        "lon": [self.m.bus.loc[6751, "lon"], 23.410492],
                        "x": [self.m.bus.loc[6751, "x"], 765500, 821153.177687],
                        "y": [self.m.bus.loc[6751, "y"], 7760000, 7780815.596067],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6751,
                        "bus1": 6747,
                        "length": 122518.2136,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6751, "lat"], 69.935012],
                        "lon": [self.m.bus.loc[6751, "lon"], 23.410492],
                        "x": [self.m.bus.loc[6751, "x"], 785500, 821153.177687],
                        "y": [self.m.bus.loc[6751, "y"], 7740000, 7780815.596067],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6747,
                        "bus1": 6746,
                        "length": 66002.682058,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [69.935012, 70.363091],
                        "lon": [23.410492, 24.613495],
                        "x": [821153.177687, 817000, 845000, 859255.88589],
                        "y": [7780815.596067, 7791500, 7830000, 7834833.210918],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6747,
                        "bus1": 6746,
                        "length": 66002.682058,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [69.935012, 70.363091],
                        "lon": [23.410492, 24.613495],
                        "x": [821153.177687, 810000, 838000, 859255.88589],
                        "y": [7780815.596067, 7791500, 7830000, 7834833.210918],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6746,
                        "bus1": 6748,
                        "length": self.m.line.loc[1159, "length"],
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6746, "lat"], self.m.bus.loc[6748, "lat"]],
                        "lon": [self.m.bus.loc[6746, "lon"], self.m.bus.loc[6748, "lon"]],
                        "x": [self.m.bus.loc[6746, "x"], 867000, 886000, self.m.bus.loc[6748, "x"]],
                        "y": [self.m.bus.loc[6746, "y"], 7834000, 7800000, self.m.bus.loc[6748, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6745,
                        "bus1": 6748,
                        "length": self.m.line.loc[1157, "length"],
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6745, "lat"], self.m.bus.loc[6748, "lat"]],
                        "lon": [self.m.bus.loc[6745, "lon"], self.m.bus.loc[6748, "lon"]],
                        "x": [self.m.bus.loc[6745, "x"], 920000, 889000, self.m.bus.loc[6748, "x"]],
                        "y": [self.m.bus.loc[6745, "y"], 7838000, 7800000, self.m.bus.loc[6748, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO4",
                        "area1": "NO4",
                        "bus0": 6738,
                        "bus1": 6745,
                        "length": self.m.line.loc[1279, "length"],
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6738, "lat"], self.m.bus.loc[6745, "lat"]],
                        "lon": [self.m.bus.loc[6738, "lon"], self.m.bus.loc[6745, "lon"]],
                        "x": [self.m.bus.loc[6738, "x"], 998000, 941000, self.m.bus.loc[6745, "x"]],
                        "y": [self.m.bus.loc[6738, "y"], 7845000, 7845000, self.m.bus.loc[6745, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO2",
                        "area1": "NO2",
                        "bus0": 6200,
                        "bus1": 6448,
                        "length": 66628.8047,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6200, "lat"], self.m.bus.loc[6448, "lat"]],
                        "lon": [self.m.bus.loc[6200, "lon"], self.m.bus.loc[6448, "lon"]],
                        "x": [self.m.bus.loc[6200, "x"], self.m.bus.loc[6448, "x"]],
                        "y": [self.m.bus.loc[6200, "y"], self.m.bus.loc[6448, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO2",
                        "area1": "NO2",
                        "bus0": 6492,
                        "bus1": 6433,
                        "length": 83920,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6492, "lat"], self.m.bus.loc[6433, "lat"]],
                        "lon": [self.m.bus.loc[6492, "lon"], self.m.bus.loc[6433, "lon"]],
                        "x": [self.m.bus.loc[6492, "x"], -38000, self.m.bus.loc[6433, "x"]],
                        "y": [self.m.bus.loc[6492, "y"], 6635000, self.m.bus.loc[6433, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas + Google Maps",
                        "info": {},
                    },
                    {
                        "area0": "NO5",
                        "area1": "NO5",
                        "bus0": 6493,
                        "bus1": 6484,
                        "length": (self.m.line.loc[1190, "length"] + self.m.line.loc[1192, "length"] + self.m.line.loc[
                            1296, "length"]),
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6493, "lat"], self.m.bus.loc[6484, "lat"]],
                        "lon": [self.m.bus.loc[6493, "lon"], self.m.bus.loc[6484, "lon"]],
                        "x": [self.m.bus.loc[6493, "x"], self.m.bus.loc[6484, "x"]],
                        "y": [self.m.bus.loc[6493, "y"], self.m.bus.loc[6484, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO5",
                        "area1": "NO5",
                        "bus0": 6493,
                        "bus1": 6413,
                        "length": (11888.7894 + 27337.4532 + 28697.5132 + 4752.0554),
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6493, "lat"], self.m.bus.loc[6413, "lat"]],
                        "lon": [self.m.bus.loc[6493, "lon"], self.m.bus.loc[6413, "lon"]],
                        "x": [self.m.bus.loc[6493, "x"], -38500, -11000, self.m.bus.loc[6413, "x"]],
                        "y": [self.m.bus.loc[6493, "y"], 6775000, 6783000, self.m.bus.loc[6413, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO2",
                        "area1": "NO2",
                        "bus0": 6210,
                        "bus1": 6455,
                        "length": self.m.line.loc[1232, "length"],
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6210, "lat"], self.m.bus.loc[6455, "lat"]],
                        "lon": [self.m.bus.loc[6210, "lon"], self.m.bus.loc[6455, "lon"]],
                        "x": [self.m.bus.loc[6210, "x"], 148000, 195000, self.m.bus.loc[6455, "x"]],
                        "y": [self.m.bus.loc[6210, "y"], 6510000, 6560000, self.m.bus.loc[6455, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO2",
                        "area1": "NO2",
                        "bus0": 6455,
                        "bus1": 6463,
                        "length": 46760,
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6455, "lat"], self.m.bus.loc[6463, "lat"]],
                        "lon": [self.m.bus.loc[6455, "lon"], self.m.bus.loc[6463, "lon"]],
                        "x": [self.m.bus.loc[6455, "x"], self.m.bus.loc[6463, "x"]],
                        "y": [self.m.bus.loc[6455, "y"], self.m.bus.loc[6463, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas + Google Maps",
                        "info": {},
                    },
                    {
                        "area0": "NO3",
                        "area1": "NO3",
                        "bus0": 6609,
                        "bus1": 6617,
                        "length": (43190.5403 + 24746.9837 + 25145.7712),
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6609, "lat"], self.m.bus.loc[6617, "lat"]],
                        "lon": [self.m.bus.loc[6609, "lon"], self.m.bus.loc[6617, "lon"]],
                        "x": [self.m.bus.loc[6609, "x"], 129000, self.m.bus.loc[6617, "x"]],
                        "y": [self.m.bus.loc[6609, "y"], 6973000, self.m.bus.loc[6617, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas",
                        "info": {},
                    },
                    {
                        "area0": "NO3",
                        "area1": "NO3",
                        "bus0": 6682,
                        "bus1": 6609,
                        "length": (47516.3989 + 63649.3912 + 67100 + 37799.0132 + 82057.4203),
                        "circuits": 1,
                        "Vbase": 380,
                        "ug": False,
                        "uc": 0,
                        "lat": [self.m.bus.loc[6682, "lat"], self.m.bus.loc[6609, "lat"]],
                        "lon": [self.m.bus.loc[6682, "lon"], self.m.bus.loc[6609, "lon"]],
                        "x": [self.m.bus.loc[6682, "x"], 292000, 270000, 240000, 184816.98256803, self.m.bus.loc[6609, "x"]],
                        "y": [self.m.bus.loc[6682, "y"], 7140000, 7093000, 7045000, 7010453.31545183,
                              self.m.bus.loc[6609, "y"]],
                        "source": "Pypsa 2019-09-04 + NVE Atlas + Google Maps",
                        "info": {},
                    },
                ],
                index=[9980, 9981, 9982, 9983, 9984, 9985, 9986, 9987, 9988, 9989, 9990, 9991, 9992, 9993, 9994, 9995, 9996,
                       9997, 9998, 9999],
            )

            self.m.line = self.m.line._append(newLines)

            for line in [9980, 9981, 9982, 9983, 9984, 9985, 9986, 9987, 9988, 9989, 9990, 9991, 9992, 9993, 9994, 9995, 9996,
                         9997, 9998, 9999]:
                connectedBusses.append(self.m.line.loc[line, "bus0"])

            for bus in connectedBusses:
                self.m.bus.loc[bus, "Vbase"] = 380

            self.m.branch_params()



    def linkReset(self, resetMax = False, resetNegative = True, resetAll = False, seperateCountry=[False, "NO"]):
        """Changes the powerflow between Scandinavia and the rest of Europe on the models HVDC links.
        if ResetMax = True -> No import or export
        if ResetNegative = True -> No export
        if resetMax = True -> Max import

        Unused function in the SMR case study analysis.
        """


        #HVDCAfter2018 = pd.DataFrame([{4329: 0, 9999: 0, 11565: 0}], index=['20180120:18'])
        #link = pd.concat([link, HVDCAfter2018], axis=0)
        applicableBidz = self.m.bidz
        if seperateCountry[0]:
            applicableBidz = [item for item in self.m.bidz if item.startswith(seperateCountry[1])]

        if resetNegative == True:  #No export from Scandinavia
            """if area0 in Scandinavia and positive P -> Import to Scandinavia, 
               if area1 in Scandinavia and negative P -> Import to Scandinavia"""
            for column in self.link:
                area0 = self.m.link.at[column, "area0"]
                area1 = self.m.link.at[column,"area1"]
                if area0 in applicableBidz:         #if area0 in Scandinavia and positive P -> Import to Scandinavia
                    self.link[column] = self.link[column].clip(lower=0)
                elif area1 in applicableBidz:        #if area1 in Scandinavia and negative P, Import to Scandinavia
                    self.link[column] = self.link[column].clip(upper=0)

        if resetMax == True:       #Import to Scandinavia at max capacity
            for column in self.link:
                #Denmark
                if column == 11552:  # Storebaelt: DK2(area0)-DK1 - 400KV
                    self.link[column] = 600
                elif column == 11531:  # kontek: DK2(area0)-DE - 400KV
                    self.link[column] = 600

                #Norway
                elif column == 4329:  # North Sea Link: NO2(area1)-GBR - 515KV - 1400 MW (2021)
                    self.link[column] = -1400
                elif column == 9999:  # NordLink: NO2(area0)-DE - 525KV - 1400 MW (2021)
                    self.link[column] = 1400

                elif column == 9490:  # NordNed: NO2(area1)-NL - 450KV
                    self.link[column] = -700
                elif column == 11384:  # Skagerak: NO2(area0)-DK1 - 300KV
                    self.link[column] = 440
                elif column == 237:  # Store-Belt1: NO2(area1)-DK1 - 250KV
                    self.link[column] = -250
                elif column == 381:  # Store-Belt2: NO2(area1)-DK1 - 250KV
                    self.link[column] = -250

                elif column == 1328:  # NO-RU: NO4(area0)-RU - 150KV
                    self.link[column] = 150
                    #link[column] = 0

                #Sweden
                elif column == 238:  # konti-Skan: SE3(area0)-DK1 - 280KV
                    self.link[column] = 250
                elif column == 239:  # konti-Skan2: SE3(area0)-DK1 - 300KV
                    self.link[column] = 300
                elif column == 542:  # Baltic cable: SE4(area0)-DE - 400KV
                    self.link[column] = 600
                elif column == 1351:  # Swe-Pol: SE4(area1)-PL - 450KV
                    self.link[column] = -600
                elif column == 1145:  # Nord Balt: SE4(area1)-LT - 300KV
                    self.link[column] = -700

                elif column == 11565:  # SydVästlänken: SE3(area0) - SE4(area1) - 300KV - 2*720 MW (2020)
                    self.link[column] = 0

                #Finland
                elif column == 499:  # Estlink: FI(area0)-EE - 150 KV
                    self.link[column] = 350
                elif column == 512:  # Estlink2: FI(area1)-EE - 450KV
                    self.link[column] = -650

                elif column == 9998:  # FI-RUS: FI(area1)-RU - 2x 400KV
                    self.link[column] = -3000
                    #link[column] = 0

                #Finland-Sweeden
                elif column == 432:  # Fenno-Skan 1: FI(area0)-SE3 - 400 KV - 500 MW
                    self.link[column] = 0

                elif column == 500:  # Fenno-Skan 2: FI(area0)-SE3 - 500 KV - 800 MW
                    self.link[column] = 0

                #links not incorporated into model
                """
                *Norway
                - Skagerak 4: NO2-DK1 - 500KV - 700 MW (2015)
                incorporated 2021:
                    - North Sea Link: NO2-GBR - 515KV - 1400 MW (2021)
                    - NordLink: NO2-DE - 525KV - 1400 MW (2021)
                *Finland
                 -Estlink 3: FI-EE - 700-1000 MW (2035)
                """

        if resetAll == True:       #No import or export
            for column in self.link:
                self.link[column] = self.link[column].clip(lower=0)
                self.link[column] = self.link[column].clip(upper=0)


    def importCase(self, importCase = None):
        """This function selects an import case between premade import scenarios."""

        if importCase == "Sweden":
            # Import from Sweden to Southern Norway --- At Max Capacity = 4500MW
            self.link[10] = 1500   #Hasle
            self.link[9] = -1500   #Halden
            self.link[12] = -1500  #Nea

        elif importCase == "West-Europe":
            # Import from rest of Western Europe to Norway trough HVDC Sea Cables --- At Max Capacity = 4500 MW
            HVDCAfter2018 = pd.DataFrame([{1: -1400, 5: 1400}], index=[pd.to_datetime(self.simulationTime, format="%Y%m%d:%H")])
            self.link = self.link.join(HVDCAfter2018, how='outer')

            for column in self.link:
                if column == 1:  # North Sea Link: NO2(area1)-GBR - 515KV - 1400 MW (2021)  #4329
                    self.link[column] = -1400

                elif column == 5:  # NordLink: NO2(area0)-DE - 525KV - 1400 MW (2021)       #9999
                    self.link[column] = 1400

                elif column == 0:  # NordNed: NO2(area1)-NL - 450KV                         #9490
                    self.link[column] = -700
                elif column == 4:  # Skagerak: NO2(area0)-DK1 - 300KV                       #11384
                    self.link[column] = 500
                elif column == 3:  # Store-Belt1: NO2(area1)-DK1 - 250KV                    #237
                    self.link[column] = -250
                elif column == 2:  # Store-Belt2: NO2(area1)-DK1 - 250KV                    #381
                    self.link[column] = -250


        elif importCase == "Both":
            #Import from both Sweden and Western Europe --- At Max Capacity = 9000MW
            self.link[10] = 1500
            self.link[9] = -1500
            self.link[12] = -1500

            HVDCAfter2018 = pd.DataFrame([{1: -1400, 5: 1400}], index=[pd.to_datetime(self.simulationTime, format="%Y%m%d:%H")])
            self.link = self.link.join(HVDCAfter2018, how='outer')

            for column in self.link:
                if column == 1:  # North Sea Link: NO2(area1)-GBR - 515KV - 1400 MW (2021)  #4329
                    self.link[column] = -1400

                elif column == 5:  # NordLink: NO2(area0)-DE - 525KV - 1400 MW (2021)       #9999
                    self.link[column] = 1400

                elif column == 0:  # NordNed: NO2(area1)-NL - 450KV                         #9490
                    self.link[column] = -700
                elif column == 4:  # Skagerak: NO2(area0)-DK1 - 300KV                       #11384
                    self.link[column] = 500
                elif column == 3:  # Store-Belt1: NO2(area1)-DK1 - 250KV                    #237
                    self.link[column] = -250
                elif column == 2:  # Store-Belt2: NO2(area1)-DK1 - 250KV                    #381
                    self.link[column] = -250



    def loadCase(self, loadCase = 0):
        """This function adds new load points to the system depending on the selected case."""
        newloadPoints = []
        if loadCase == 1: #Case 1: load points Norway >500 MW, Low Voltage Conection  # =5000MW

            #NO1
            self.m.bus.loc[6431, "load"] += 500  # Ringeriket - NO1
            #m.bus.loc[6432, "load"] += 500  # Ådal - NO1

            #NO2
            self.m.bus.loc[6467, "load"] += 500  # Rød
            self.m.bus.loc[6467, "load"] += 500  # Rød
            self.m.bus.loc[6455, "load"] += 500  # Skien

            self.m.bus.loc[6208, "load"] += 500  # Kristiansand
            self.m.bus.loc[6207, "load"] += 500  # Feda
            self.m.bus.loc[6200, "load"] += 500  # Fagrafjell

            # NO4
            self.m.bus.loc[6787, "load"] += 500  # Røssåga - NO4

            #NO5
            self.m.bus.loc[6484, "load"] += 500  # Samnanger
            self.m.bus.loc[6405, "load"] += 500  # Sogndal

            newloadPoints = [6431, 6467, 6455, 6208, 6207, 6200, 6787, 6484, 6405]

        elif loadCase == 2: #Case 2: load points Norway >500 MW, High Voltage Conection  #=5000MW

            #NO1
            self.m.bus.loc[6431, "load"] += 500  # Ringeriket - NO1
            #m.bus.loc[6432, "load"] += 500  # Ådal - NO1

            #NO2
            self.m.bus.loc[6468, "load"] += 500  # Rød
            self.m.bus.loc[6468, "load"] += 500  # Rød
            self.m.bus.loc[6455, "load"] += 500  # Skien

            self.m.bus.loc[6209, "load"] += 500  # Kristiansand
            self.m.bus.loc[6207, "load"] += 500  # Feda
            self.m.bus.loc[6200, "load"] += 500  # Fagrafjell

            # NO4
            self.m.bus.loc[6789, "load"] += 500  # Røssåga - NO4

            #NO5
            self.m.bus.loc[6485, "load"] += 500  # Samnanger
            self.m.bus.loc[6407, "load"] += 500  # Sogndal

            newloadPoints = [6431, 6468, 6455, 6208, 6209, 6200, 6789, 6485, 6407]

        elif loadCase == 3: #Case 3: load points Norway >850 MW, Low Voltage Conection

            #NO1
            self.m.bus.loc[6431, "load"] += 850  # Ringeriket - NO1
            #m.bus.loc[6432, "load"] += 500  # Ådal - NO1

            #NO2
            self.m.bus.loc[6467, "load"] += 850  # Rød


            self.m.bus.loc[6208, "load"] += 850  # Kristiansand
            self.m.bus.loc[6207, "load"] += 850  # Feda
            self.m.bus.loc[6200, "load"] += 850  # Fagrafjell

            # NO4
            self.m.bus.loc[6787, "load"] += 850  # Røssåga - NO4

            #NO5
            self.m.bus.loc[6484, "load"] += 850  # Samnanger
            self.m.bus.loc[6405, "load"] += 850  # Sogndal

            newloadPoints = [6431, 6467, 6455, 6208, 6207, 6200, 6787, 6484, 6405]

        elif loadCase == 4: #Case 4: load points Norway 0 MW, Low Voltage Conection
            """
            # NO1
            self.m.bus.loc[6431, "load"] += 500  # Ringeriket - NO1
            # m.bus.loc[6432, "load"] += 500  # Ådal - NO1

            # NO2
            self.m.bus.loc[6467, "load"] += 500  # Rød
            self.m.bus.loc[6467, "load"] += 500  # Rød
            self.m.bus.loc[6455, "load"] += 500  # Skien

            self.m.bus.loc[6208, "load"] += 500  # Kristiansand
            self.m.bus.loc[6207, "load"] += 500  # Feda
            self.m.bus.loc[6200, "load"] += 500  # Fagrafjell

            # NO4
            self.m.bus.loc[6787, "load"] += 500  # Røssåga - NO4

            # NO5
            self.m.bus.loc[6484, "load"] += 500  # Samnanger
            self.m.bus.loc[6405, "load"] += 500  # Sogndal
            """
            newloadPoints = [6431, 6467, 6455, 6208, 6207, 6200, 6787, 6484, 6405]

        elif loadCase == 5: #Case 4: load points Norway >500 MW, Low Voltage Conection # =9000MW

            #NO1
            self.m.bus.loc[6431, "load"] += 900  # Ringeriket - NO1
            #m.bus.loc[6432, "load"] += 500  # Ådal - NO1

            #NO2
            self.m.bus.loc[6467, "load"] += 900  # Rød
            self.m.bus.loc[6467, "load"] += 900  # Rød
            self.m.bus.loc[6455, "load"] += 900  # Skien

            self.m.bus.loc[6208, "load"] += 900  # Kristiansand
            self.m.bus.loc[6207, "load"] += 900  # Feda
            self.m.bus.loc[6200, "load"] += 900  # Fagrafjell

            # NO4
            self.m.bus.loc[6787, "load"] += 900  # Røssåga - NO4

            #NO5
            self.m.bus.loc[6484, "load"] += 900  # Samnanger
            self.m.bus.loc[6405, "load"] += 900  # Sogndal

            newloadPoints = [6431, 6467, 6455, 6208, 6207, 6200, 6787, 6484, 6405]
        return newloadPoints




    def prodCase(self, prodCase=0, clusterbus = None):
        """This function adds new generators to the system depending on the selected case."""

        if prodCase == 1:  # Case 1: SMR Co-located with new Loadpoints
            Pmax = 300
            pf = 0.9
            case = pd.DataFrame(
                [
                    {
                        "name": "testnuc1",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    }, #^ Ringeriket1
                    {
                        "name": "testnuc2",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Ringeriket2
                    {
                        "name": "testnuc3",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    }, #^ Rød1
                    {
                        "name": "testnuc4",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Rød2
                    {
                        "name": "testnuc5",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ Rød3
                    {
                        "name": "testnuc6",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Rød4
                    {
                        "name": "testnuc7",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6455,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ Skien1
                    {
                        "name": "testnuc8",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6455,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Skien2
                    {
                        "name": "testnuc9",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6208,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    }, #^ Kristiansand1
                    {
                        "name": "testnuc10",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6208,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Kristiansand2
                    {
                        "name": "testnuc11",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6207,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },#^ Feda1
                    {
                        "name": "testnuc12",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6207,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Feda2
                    {
                        "name": "testnuc13",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6200,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ Fagrafjell1
                    {
                        "name": "testnuc14",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6200,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Fagrafjell2
                    {
                        "name": "testnuc15",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO4",
                        "bus": 6787,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ Røssåga1
                    {
                        "name": "testnuc16",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO4",
                        "bus": 6787,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Røssåga2
                    {
                        "name": "testnuc17",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO5",
                        "bus": 6484,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ Samnanger1
                    {
                        "name": "testnuc18",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO5",
                        "bus": 6484,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Samnanger2
                    {
                        "name": "testnuc19",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO5",
                        "bus": 6405,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ Sogndal1
                    {
                        "name": "testnuc20",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO5",
                        "bus": 6405,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Sogndal2
                ],
                index=[9980, 9981, 9982, 9983, 9984, 9985, 9986, 9987, 9988, 9989, 9990, 9991, 9992, 9993, 9994, 9995, 9996, 9997, 9998, 9999],
            )
            self.m.gen = self.m.gen._append(case)

        elif prodCase == 2:  # Case 1: SMR Co-located with new Loadpoints
            Pmax = 2*300
            pf = 0.9
            case = pd.DataFrame(
                [
                    {
                        "name": "testnuc1",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    }, #^ Ringeriket1
                    {
                        "name": "testnuc2",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Ringeriket2
                    {
                        "name": "testnuc3",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    }, #^ Rød1
                    {
                        "name": "testnuc4",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Rød2
                    {
                        "name": "testnuc5",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ Rød3
                    {
                        "name": "testnuc6",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Rød4
                    {
                        "name": "testnuc7",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6455,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ Skien1
                    {
                        "name": "testnuc8",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6455,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Skien2
                    {
                        "name": "testnuc9",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6208,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    }, #^ Kristiansand1
                    {
                        "name": "testnuc10",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6208,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Kristiansand2
                    {
                        "name": "testnuc11",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6207,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },#^ Feda1
                    {
                        "name": "testnuc12",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6207,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Feda2
                    {
                        "name": "testnuc13",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6200,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ Fagrafjell1
                    {
                        "name": "testnuc14",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO2",
                        "bus": 6200,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Fagrafjell2
                    {
                        "name": "testnuc15",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO4",
                        "bus": 6787,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ Røssåga1
                    {
                        "name": "testnuc16",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO4",
                        "bus": 6787,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Røssåga2
                    {
                        "name": "testnuc17",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO5",
                        "bus": 6484,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ Samnanger1
                    {
                        "name": "testnuc18",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO5",
                        "bus": 6484,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Samnanger2
                    {
                        "name": "testnuc19",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO5",
                        "bus": 6405,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ Sogndal1
                    {
                        "name": "testnuc20",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO5",
                        "bus": 6405,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ Sogndal2
                ],
                index=[9980, 9981, 9982, 9983, 9984, 9985, 9986, 9987, 9988, 9989, 9990, 9991, 9992, 9993, 9994, 9995, 9996, 9997, 9998, 9999],
            )
            self.m.gen = self.m.gen._append(case)

        elif prodCase == 25:  # Case 2: SMR Co-located with new Loadpoints
            case = pd.DataFrame(
                [
                    {
                        "name": "testnuc1",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 1000,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": 950,
                    }, #^ Ringeriket
                    {
                        "name": "testnuc2",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 1000,
                        "bidz": "NO2",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": 950,
                    }, #^ Rød1
                    {
                        "name": "testnuc3",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 1000,
                        "bidz": "NO2",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": 950,
                    },  # ^ Rød2
                    {
                        "name": "testnuc4",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 1000,
                        "bidz": "NO2",
                        "bus": 6455,
                        "uc": 0,
                        "country": "NO",
                        "P": 950,
                    },  # ^ Skien
                    {
                        "name": "testnuc5",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 1000,
                        "bidz": "NO2",
                        "bus": 6208,
                        "uc": 0,
                        "country": "NO",
                        "P": 950,
                    }, #^ Kristiansand
                    {
                        "name": "testnuc6",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 1000,
                        "bidz": "NO2",
                        "bus": 6207,
                        "uc": 0,
                        "country": "NO",
                        "P": 950,
                    },#^ Feda
                    {
                        "name": "testnuc7",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 1000,
                        "bidz": "NO2",
                        "bus": 6200,
                        "uc": 0,
                        "country": "NO",
                        "P": 950,
                    },  # ^ Fagrafjell
                    {
                        "name": "testnuc8",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 1000,
                        "bidz": "NO4",
                        "bus": 6787,
                        "uc": 0,
                        "country": "NO",
                        "P": 950,
                    },  # ^ Røssåga
                    {
                        "name": "testnuc9",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 1000,
                        "bidz": "NO5",
                        "bus": 6484,
                        "uc": 0,
                        "country": "NO",
                        "P": 950,
                    },  # ^ Samnanger
                    {
                        "name": "testnuc10",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 1000,
                        "bidz": "NO5",
                        "bus": 6405,
                        "uc": 0,
                        "country": "NO",
                        "P": 950,
                    },  # ^ Sogndal
                ],
                index=[9990, 9991, 9992, 9993, 9994, 9995, 9996, 9997, 9998, 9999],
            )
            self.m.gen = self.m.gen._append(case)

        elif prodCase == 3:
            case = pd.DataFrame(
                [
                    {
                        "name": "testnuc1",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Ringeriket1
                    {
                        "name": "testnuc2",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Ringeriket2
                    {
                        "name": "testnuc3",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Ringeriket3
                    {
                        "name": "testnuc4",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Ringeriket4
                    {
                        "name": "testnuc5",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Ringeriket5
                    {
                        "name": "testnuc6",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Ringeriket6
                    {
                        "name": "testnuc7",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Ringeriket7
                    {
                        "name": "testnuc8",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Ringeriket8
                    {
                        "name": "testnuc9",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Ringeriket9
                    {
                        "name": "testnuc10",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6431,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Ringeriket10
                ],
                index=[9990, 9991, 9992, 9993, 9994, 9995, 9996, 9997, 9998, 9999],
            )
            self.m.gen = self.m.gen._append(case)

        elif prodCase == 4:
            case = pd.DataFrame(
                [
                    {
                        "name": "testnuc1",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Rød1
                    {
                        "name": "testnuc2",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Rød2
                    {
                        "name": "testnuc3",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Rød3
                    {
                        "name": "testnuc4",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Rød4
                    {
                        "name": "testnuc5",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Rød5
                    {
                        "name": "testnuc6",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Rød6
                    {
                        "name": "testnuc7",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Rød7
                    {
                        "name": "testnuc8",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Rød8
                    {
                        "name": "testnuc9",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Rød9
                    {
                        "name": "testnuc10",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6467,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Rød10

                ],
                index=[9990, 9991, 9992, 9993, 9994, 9995, 9996, 9997, 9998, 9999],
            )
            self.m.gen = self.m.gen._append(case)

        elif prodCase == 5:
            case = pd.DataFrame(
                [
                    {
                        "name": "testnuc1",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6464,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen1
                    {
                        "name": "testnuc2",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6464,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen2
                    {
                        "name": "testnuc3",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6464,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen3
                    {
                        "name": "testnuc4",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6464,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen4
                    {
                        "name": "testnuc5",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6464,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen5
                    {
                        "name": "testnuc6",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6464,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen6
                    {
                        "name": "testnuc7",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6464,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen7
                    {
                        "name": "testnuc8",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6464,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen8
                    {
                        "name": "testnuc9",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6464,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen9
                    {
                        "name": "testnuc10",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": 6464,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen10

                ],
                index=[9990, 9991, 9992, 9993, 9994, 9995, 9996, 9997, 9998, 9999],
            )
            self.m.gen = self.m.gen._append(case)

        elif prodCase == 6:
            clusterBus = clusterbus
            if clusterBus == None:
                clusterBus = 6465 #Sylling bus

            case = pd.DataFrame(
                [
                    {
                        "name": "testnuc1",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen1
                    {
                        "name": "testnuc2",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen2
                    {
                        "name": "testnuc3",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen3
                    {
                        "name": "testnuc4",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen4
                    {
                        "name": "testnuc5",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen5
                    {
                        "name": "testnuc6",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen6
                    {
                        "name": "testnuc7",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen7
                    {
                        "name": "testnuc8",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen8
                    {
                        "name": "testnuc9",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen9
                    {
                        "name": "testnuc10",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": 600,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": 500,
                    },  # ^ Drammen10

                ],
                index=[9990, 9991, 9992, 9993, 9994, 9995, 9996, 9997, 9998, 9999],
            )
            self.m.gen = self.m.gen._append(case)

        elif prodCase == 7:
            clusterBus = clusterbus
            Pmax = 300
            pf = 0.9
            if clusterBus == None:
                clusterBus = 6465 #Sylling bus

            case = pd.DataFrame(
                [
                    {
                        "name": "testnuc1",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR1
                    {
                        "name": "testnuc2",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR2
                    {
                        "name": "testnuc3",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR3
                    {
                        "name": "testnuc4",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR4
                    {
                        "name": "testnuc5",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR5
                    {
                        "name": "testnuc6",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR6
                    {
                        "name": "testnuc7",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR7
                    {
                        "name": "testnuc8",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR8
                    {
                        "name": "testnuc9",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR9
                    {
                        "name": "testnuc10",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR10
                    {
                        "name": "testnuc11",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR11
                    {
                        "name": "testnuc12",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR12
                    {
                        "name": "testnuc13",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR13
                    {
                        "name": "testnuc14",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR14
                    {
                        "name": "testnuc15",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR15
                    {
                        "name": "testnuc16",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR16
                    {
                        "name": "testnuc17",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR17
                    {
                        "name": "testnuc18",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR18
                    {
                        "name": "testnuc19",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR19
                    {
                        "name": "testnuc20",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR20

                ],
                index=[9980, 9981, 9982, 9983, 9984, 9985, 9986, 9987, 9988, 9989, 9990, 9991, 9992, 9993, 9994, 9995, 9996, 9997, 9998, 9999],
            )
            self.m.gen = self.m.gen._append(case)

        elif prodCase == 8:
            clusterBus = clusterbus
            Pmax = 2*300
            pf = 0.9
            if clusterBus == None:
                clusterBus = 6465 #Sylling bus

            case = pd.DataFrame(
                [
                    {
                        "name": "testnuc1",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR1
                    {
                        "name": "testnuc2",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR2
                    {
                        "name": "testnuc3",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR3
                    {
                        "name": "testnuc4",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR4
                    {
                        "name": "testnuc5",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR5
                    {
                        "name": "testnuc6",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR6
                    {
                        "name": "testnuc7",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR7
                    {
                        "name": "testnuc8",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR8
                    {
                        "name": "testnuc9",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR9
                    {
                        "name": "testnuc10",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax*pf,
                    },  # ^ ClusterSMR10
                    {
                        "name": "testnuc11",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR11
                    {
                        "name": "testnuc12",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR12
                    {
                        "name": "testnuc13",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR13
                    {
                        "name": "testnuc14",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR14
                    {
                        "name": "testnuc15",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR15
                    {
                        "name": "testnuc16",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR16
                    {
                        "name": "testnuc17",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR17
                    {
                        "name": "testnuc18",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR18
                    {
                        "name": "testnuc19",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR19
                    {
                        "name": "testnuc20",
                        "type": "Nuclear",
                        "type2": "Nuclear",
                        "Pmax": Pmax,
                        "bidz": "NO1",
                        "bus": clusterBus,
                        "uc": 0,
                        "country": "NO",
                        "P": Pmax * pf,
                    },  # ^ ClusterSMR20

                ],
                index=[9980, 9981, 9982, 9983, 9984, 9985, 9986, 9987, 9988, 9989, 9990, 9991, 9992, 9993, 9994, 9995, 9996, 9997, 9998, 9999],
            )
            self.m.gen = self.m.gen._append(case)

        elif prodCase == 9: #Case 9: Offshore Wind (Nordsjø II/Kvinesdal) NO2
            case = pd.DataFrame(
                [
                    {
                        "name": "testoffshorewind2",
                        "type": "wind",
                        "type2": "wind",
                        "Pmax": 1500,
                        "bidz": "NO2",
                        "bus": 6207,
                        "uc": 0,
                        "country": "NO",
                        "P": 1500,
                    },  #^ Sørlig Nordsjø II
                    {
                        "name": "testoffshorewind3",
                        "type": "wind",
                        "type2": "wind",
                        "Pmax": 1500,
                        "bidz": "NO2",
                        "bus": 6492,
                        "uc": 0,
                        "country": "NO",
                        "P": 1500,
                    },  #^ Utsira Nord
                ],
                index=[9995, 9996],
            )
            self.m.gen = self.m.gen._append(case)

        elif prodCase == 10:  # Case 10: Offshore Wind (Nordsjø II/Kvinesdal) NO2
            self.m.bus.loc[6207, "load"] += -1500
            self.m.bus.loc[6492, "load"] += -1500

            newgenPoints=[6207, 6492]
            return newgenPoints

        elif prodCase == 11:  # Case 11: Offshore Wind (Nordsjø II/Kvinesdal) NO2
            pf = 0.47
            #pf = 1
            self.m.bus.loc[6207, "load"] += -1500*pf
            self.m.bus.loc[6492, "load"] += -1500*pf

            newgenPoints = [6207, 6492]
            return newgenPoints

        elif prodCase == 12:  # Case 12: Offshore Wind (Nordsjø II/Kvinesdal) NO2
            pf = 0.47
            #pf = 1
            self.m.bus.loc[6207, "load"] += -1500*pf
            self.m.bus.loc[6492, "load"] += -1500*pf

            self.m.bus.loc[6493, "load"] += -1500 * pf  #Øygården
            self.m.bus.loc[6455, "load"] += -1500 * pf  #Skien
            self.m.bus.loc[6200, "load"] += -1500 * pf  #Fagrafjell
            self.m.bus.loc[6608, "load"] += -1500 * pf  #Aura

            newgenPoints = [6207, 6492, 6493, 6455, 6200, 6608]
            return newgenPoints

        if not prodCase == 0:
            newgenPoints=[]
            for indx, row in case.iterrows():
                newgenPoints.append(case.loc[indx,"bus"])
            return newgenPoints




    def genPmaxViolation(self):
        """This function prints result for generator Pmax limit violations."""
        from numpy import flatnonzero as find
        PmaxViolations = find(self.m.solved_mpc[0][0]["gen"][:, 1] > self.m.solved_mpc[0][0]["gen"][:, 8])
        PmaxViolationsNegative = find(self.m.solved_mpc[0][0]["gen"][:, 1] < self.m.solved_mpc[0][0]["gen"][:, 9])
        slackBus = find(self.m.solved_mpc[0][0]["bus"][:, 1] == 3)

        sumLoad = self.m.solved_mpc[0][0]["bus"][:, 2].sum()
        sumGen = self.m.solved_mpc[0][0]["gen"][:, 1].sum()
        print("\n")
        print("--- Generator P violations: ---")
        print("Sum Production in system: " + str(sumGen * 10 ** -3) + " GW")
        print("Sum Load in system: " + str(sumLoad*10**-3) + " GW")
        print("Slack bus: " + str(self.m.solved_mpc[0][0]["bus"][slackBus,0]))
        print("\n")
        print("Generators producing greater P than their Pmax: " + str(len(PmaxViolations)))
        print("Collective amount over limit: " + str(self.m.solved_mpc[0][0]["gen"][PmaxViolations,1].sum() - self.m.solved_mpc[0][0]["gen"][PmaxViolations,8].sum()) + " MW")
        print("Generators with Pmax Violations connected to buses: " + str(np.unique(self.m.solved_mpc[0][0]["gen"][PmaxViolations,0])))

        print("Generators producing less P than their Pmin: " + str(len(PmaxViolationsNegative)))
        print("Collective amount under limit: " + str(self.m.solved_mpc[0][0]["gen"][PmaxViolationsNegative, 9].sum() + self.m.solved_mpc[0][0]["gen"][PmaxViolationsNegative, 1].sum()) + " MW")
        print("Generators with Pmax Violations connected to buses: " + str(np.unique(self.m.solved_mpc[0][0]["gen"][PmaxViolationsNegative, 0])))



    def genQmaxViolation(self):
        """This function prints result for generator Qmax limit violations."""
        from numpy import flatnonzero as find
        QmaxViolations = find(self.m.solved_mpc[0][0]["gen"][:, 2] > self.m.solved_mpc[0][0]["gen"][:, 3])
        QmaxViolationsNegative = find(self.m.solved_mpc[0][0]["gen"][:, 2] < self.m.solved_mpc[0][0]["gen"][:, 4])
        slackBus = find(self.m.solved_mpc[0][0]["bus"][:, 1] == 3)

        #sumLoad = m.solved_mpc[0][0]["bus"][:, 2].sum()
        #sumGen = m.solved_mpc[0][0]["gen"][:, 1].sum()
        print("\n")
        print("--- Generator Q violations: ---")
        #print("Sum Production in system: " + str(sumGen * 10 ** -3) + " GW")
        #print("Sum Load in system: " + str(sumLoad*10**-3) + " GW")
        print("Slack bus: " + str(self.m.solved_mpc[0][0]["bus"][slackBus,0]))
        print("\n")
        print("Generators producing greater Q than their Qmax: " + str(len(QmaxViolations)))
        print("Collective amount over limit: " + str(self.m.solved_mpc[0][0]["gen"][QmaxViolations,2].sum() - self.m.solved_mpc[0][0]["gen"][QmaxViolations,3].sum()) + " MW")
        print("Generators with Qmax Violations connected to buses: " + str(np.unique(self.m.solved_mpc[0][0]["gen"][QmaxViolations,0])))

        print("Generators producing less Q than their Qmin: " + str(len(QmaxViolationsNegative)))
        print("Collective amount under limit: " + str(self.m.solved_mpc[0][0]["gen"][QmaxViolationsNegative, 4].sum() + self.m.solved_mpc[0][0]["gen"][QmaxViolationsNegative, 2].sum()) + " MW")
        print("Generators with Qmax Violations connected to buses: " + str(np.unique(self.m.solved_mpc[0][0]["gen"][QmaxViolationsNegative, 0])))

    def slackGenInjection(self):
        """This function prints result for slack bus injections and generator limit violations."""
        from numpy import flatnonzero as find
        slackBus = find(self.m.solved_mpc[0][0]["bus"][:, 1] == 3)

        print("\n")
        print("--- Slack Bus Injections: ---")
        # print("Sum Production in system: " + str(sumGen * 10 ** -3) + " GW")
        # print("Sum Load in system: " + str(sumLoad*10**-3) + " GW")
        print("Slack bus: " + str(self.m.solved_mpc[0][0]["bus"][slackBus, 0]))

        print("Slackbus generator producing P amount over limit: " + str(self.m.solved_mpc[0][0]["gen"][slackBus, 1].sum() - self.m.solved_mpc[0][0]["gen"][slackBus, 8].sum()) + " MW")
        print("Slackbus generator producing P amount under limit: " + str(self.m.solved_mpc[0][0]["gen"][slackBus, 9].sum() + self.m.solved_mpc[0][0]["gen"][slackBus, 1].sum()) + " MW")
        print("Slackbus generator producing Q amount over limit: " + str(self.m.solved_mpc[0][0]["gen"][slackBus,2].sum() - self.m.solved_mpc[0][0]["gen"][slackBus,3].sum()) + " MW")
        print("Slackbus generator producing Q amount under limit: " + str(self.m.solved_mpc[0][0]["gen"][slackBus, 4].sum() + self.m.solved_mpc[0][0]["gen"][slackBus, 2].sum()) + " MW")


    def networkPlots(self, MapZoom = None): #Results plotting
        #"""
        #Buss Voltage (pu) Heatmap
        x4 = Map(self.m, MapZoom)
        x4.init_plot() # init plot (set parameters and draw the base map, mandatory)
        #x2.bus_name_fs = [7,0,0] # manually change layout parameters, see plot_settings() and set_map_properties()
        x4.add_topo() # add network on map (mandatory)
        #x4.add_heatmap('Voltage (pu)', cmap="RdYlGn", limitColors=True) # parameter name or numpy vector allowed
        x4.add_legend()
        x4.show()
        #"""


    def resultsPlots(self, MapZoom = None, plotType = "both", slack=[6434], newloadPoints=[], newgenPoints=[]): #Results plotting
        """This function creates plots for the bus voltage and line loading results."""
        #"""
        #Buss Voltage (pu) Heatmap
        if plotType in ["both", "heatmap"]:
            x2 = Map(self.m, MapZoom)
            x2.init_plot() # init plot (set parameters and draw the base map, mandatory)
            #x2.bus_name_fs = [7,0,0] # manually change layout parameters, see plot_settings() and set_map_properties()
            x2.add_topo() # add network on map (mandatory)
            #x2.add_newPoints_topo(slack=slack, newLoadPoints=newloadPoints, newGenPoints=newgenPoints) #add slackbus, new generators and new loadpoints on map
            x2.add_heatmap('Voltage (pu)', cmap="RdYlGn", clim=[0.94, 1.001], limitColors=True) # parameter name or numpy vector allowed
            #x2.add_legend()
            x2.add_legend2()
            x2.show()
        #"""

        #Line Loading Line-color map
        if plotType in ["both", "lineLoading"]:
            x3 = Map(self.m, MapZoom)
            x3.init_plot() # init plot (set parameters and draw the base map, mandatory)
            #x3.bus_name_fs = [7,0,0] # manually change layout parameters, see plot_settings() and set_map_properties()
            x3.bus_color = ["darkgrey", "darkgrey", "darkgrey"]
            #x3.add_heatmap('Line Loading') # parameter name or numpy vector allowed
            #x3.line_colors_from('Line Loading', limitColors=False, newRdYlGn2=True, cmap="RdYlGn_r")
            x3.line_colors_from2('Line Loading', limitColors=False, cmap="RdYlGn_r")
            #x3.line_widths_from('Line Loading')
            x3.add_topo() # add network on map (mandatory)
            x3.add_newPoints_topo(slack=slack, newLoadPoints=newloadPoints, newGenPoints=newgenPoints) #add slackbus, new generators and new loadpoints on map
            #x3.add_legend()
            x3.show()




    def resultsPrints(self, printFull = True, costTime = 2030): #Result printing
        """This function prints results for the bus voltage, line loading and economic assessment."""
        #--- Bus Voltage Results ---#
        #filteredBuses = self.m.bus.loc[(self.m.bus["Voltage (pu)"] >= 1.05) | (self.m.bus["Voltage (pu)"] <= 0.9)]
        #filteredBuses = self.m.bus.loc[(self.m.bus["Voltage (pu)"] >= 1.05) | (self.m.bus["Voltage (pu)"] <= 0.95)]
        #filteredBuses = self.m.bus.loc[(self.m.bus["Vbase"] >= 300 & ((self.m.bus["Voltage (pu)"] >= 1.05) | (self.m.bus["Voltage (pu)"] <= 0.95))) | (self.m.bus["Vbase"] < 300 & ((self.m.bus["Voltage (pu)"] >= 1.05) | (self.m.bus["Voltage (pu)"] <= 0.9)))]
        filteredBuses = self.m.bus.loc[
            ((self.m.bus["Vbase"] >= 300) & ((self.m.bus["Voltage (pu)"] >= 1.05) | (self.m.bus["Voltage (pu)"] <= 0.95))) |
            ((self.m.bus["Vbase"] < 300) & ((self.m.bus["Voltage (pu)"] >= 1.05) | (self.m.bus["Voltage (pu)"] <= 0.9)))]
        busAmount = len(filteredBuses)
        busesMalVoltage = filteredBuses[["name", "bidz", "Vbase", "load", "Voltage (pu)"]].copy()

        # Round the values
        busesMalVoltage["Vbase"] = busesMalVoltage["Vbase"].astype(int)
        busesMalVoltage["load"] = busesMalVoltage["load"].round(0).astype(int)
        busesMalVoltage["Voltage (pu)"] = busesMalVoltage["Voltage (pu)"].round(4)

        # Sort the DataFrame based on "Voltage (pu)" in descending order
        busesMalVoltage = busesMalVoltage.sort_values(by="Voltage (pu)", ascending=False)

        # Get the highest and lowest "Voltage (pu)" value
        maxVoltageBus = self.m.bus.loc[self.m.bus["Voltage (pu)"].idxmax()]
        minVoltageBus = self.m.bus.loc[self.m.bus["Voltage (pu)"].idxmin()]
        maxVoltage = maxVoltageBus[["name", "bidz", "Vbase", "load", "Voltage (pu)"]].copy()
        minVoltage = minVoltageBus[["name", "bidz", "Vbase", "load", "Voltage (pu)"]].copy()

        print("\n")
        print("Buses with highest and lowest Voltage (pu) value:")
        print(maxVoltage)
        print("\n")
        print(minVoltage)

        #print(filteredBuses)
        print("\n")
        print("Buses with bad voltage supply:")
        print("Amount of busses with bad voltage supply: " + str(busAmount))
        #print("Buses with voltage supply below regulatory requirements:")
        if printFull:
            print(busesMalVoltage)


        #--- Line Overloading Results ---#
        filteredLines = self.m.line.loc[(self.m.line["Line Loading"] >= 100)]
        linesAmount = len(filteredLines)
        linesOverloaded = filteredLines[["area0", "area1", "bus0", "bus1", "Vbase", "length", "Cap", "flow", "Line Loading"]].copy()

        if costTime == 2030:
            #Cost_line420KV_MillionEUR_pr_Km = 0.510
            Cost_line420KV_MillionEUR_pr_Km = 1.73
        elif costTime == 2045:
            Cost_line420KV_MillionEUR_pr_Km = 1.74

        # Round the values
        linesOverloaded["length"] = linesOverloaded["length"].round(0).astype(int)
        linesOverloaded["flow"] = linesOverloaded["flow"].round(0).astype(int)
        linesOverloaded["Line Loading"] = linesOverloaded["Line Loading"].round(0).astype(int)
        linesOverloaded["bus0"] = linesOverloaded["bus0"].astype(int)
        linesOverloaded["bus1"] = linesOverloaded["bus1"].astype(int)

        linesOverloaded["cost"] = (linesOverloaded["length"].values/1000)*Cost_line420KV_MillionEUR_pr_Km

        linesOverloaded["cost"] = linesOverloaded["cost"].round(0).astype(int).apply(lambda x: f"{x:,}".replace(',', ' '))
        linesOverloaded["length"] = linesOverloaded["length"].round(0).astype(int).apply(lambda x: f"{x:,}".replace(',', ' '))

        # Add header to the index column
        linesOverloaded.index.name = "line_id"
        #linesOverloaded.reset_index(inplace=True)

        # Sort the DataFrame based on "Line Loading" in descending order
        linesOverloaded = linesOverloaded.sort_values(by="Line Loading", ascending=False)

        # Set display options to prevent truncation
        pd.set_option('display.max_columns', None)  # Show all columns
        #pd.set_option('display.max_colwidth', None)  # Show full column content
        pd.set_option('display.width', None)  # Don't limit display width

        #print(filtered_lines)
        print("\n")
        print("Overloaded lines:")
        print("Amount of overloaded lines: " + str(linesAmount))
        if printFull:
            print(linesOverloaded)

        return busesMalVoltage, linesOverloaded


    def lineLoadingBarChart(self, data, max_bar_width=0.6):
        """This function creates line loading bar charts."""

        # Check if the dataframe is empty
        if data.empty:
            print("No lines overloaded. No chart will be generated.")
            return

        # Updating the data to include the combined area0 - area1 group
        data['combined_area'] = data.apply(lambda row: row['area0'] if row['area0'] == row['area1'] else f"{row['area0']}-{row['area1']}", axis=1)

        # Sorting the dataframe by combined_area and then by Line Loading within each area
        df_sorted = data.sort_values(by=['combined_area', 'Line Loading'], ascending=[True, False])

        # Sorting the combined areas so that the area with the line with the highest line loading is to the left
        max_loading_per_area = df_sorted.groupby('combined_area')['Line Loading'].max().sort_values(ascending=False).index
        df_sorted['combined_area'] = pd.Categorical(df_sorted['combined_area'], categories=max_loading_per_area, ordered=True)
        df_sorted = df_sorted.sort_values(by=['combined_area', 'Line Loading'], ascending=[True, False])

        # Recalculate positions with extra spacing between groups
        positions = []
        current_pos = 0
        area_labels = []
        for area in df_sorted['combined_area'].unique():
            area_lines = df_sorted[df_sorted['combined_area'] == area]
            area_labels.extend(area_lines.index.astype(str).tolist())
            #area_labels.extend([f"{index}: ({int(row['Vbase'])}kV)" for index, row in area_lines.iterrows()])
            positions.extend(range(current_pos, current_pos + len(area_lines)))
            current_pos += len(area_lines) + 1  # Add extra space between groups

        # Calculate the bar width, limiting it to max_bar_width
        num_bars = len(df_sorted)
        bar_width = min(max_bar_width, 14 / num_bars)

        # y-axis limit
        max_line_loading = df_sorted['Line Loading'].max()
        y_limit = 200 if max_line_loading <= 200 else 350

        # bar chart with the updated sorting logic
        fig, ax = plt.subplots(figsize=(14, 8))

        #bars = ax.bar(positions, df_sorted['Line Loading'], width=bar_width, color=plt.cm.Reds(df_sorted['Line Loading'] / df_sorted['Line Loading'].max()))

        # bar color based on the y limit
        bars = ax.bar(positions, df_sorted['Line Loading'], width=bar_width, color=plt.cm.Reds(df_sorted['Line Loading'] / 200))

        # x-ticks positions with the corresponding line numbers
        ax.set_xticks(positions)
        ax.set_xticklabels(area_labels, rotation=40, fontsize=15)

        # y-ticks font size
        ax.tick_params(axis='y', labelsize=16)

        # y-axis limit
        ax.set_ylim(0, y_limit)

        # second x-axis for area labels at the top
        ax2 = ax.twiny()
        ax2.set_xlim(ax.get_xlim())
        area_positions = []
        current_pos = 0
        for area in df_sorted['combined_area'].unique():
            area_lines = df_sorted[df_sorted['combined_area'] == area]
            area_positions.append(current_pos + (len(area_lines) - 1) / 2)
            current_pos += len(area_lines) + 1  # Add extra space between groups

        ax2.set_xticks(area_positions)
        ax2.set_xticklabels(df_sorted['combined_area'].unique(), fontsize=13)
        ax2.set_xlabel('Area', fontsize=16)

        # double-headed arrows for each combined area
        current_pos = 0
        for area in df_sorted['combined_area'].unique():
            area_lines = df_sorted[df_sorted['combined_area'] == area]
            start_pos = current_pos - 0.5
            end_pos = current_pos + len(area_lines) - 0.5
            ax2.annotate(
                '',
                xy=(start_pos, 1),
                xytext=(end_pos, 1),
                xycoords=('data', 'axes fraction'),
                textcoords=('data', 'axes fraction'),
                arrowprops=dict(arrowstyle='<->', color='black', lw=2),
                annotation_clip=False
            )
            current_pos += len(area_lines) + 1  # Add extra space between groups

            # dotted lines and labels at y=100 and y=130
        for y_value, label in [(100, "100% line loading"), (125, "125% line loading")]:
            ax.axhline(y=y_value, color='black', linestyle='--', linewidth=1)
            ax.text(ax.get_xlim()[1], y_value, label, va='bottom', ha="right", fontsize=17, color='black')

        # axis labels and title
        ax.set_xlabel(' Line_id:', labelpad=2, fontsize=18)  # Add padding to separate the labels
        ax.set_ylabel('Line Loading (%)', fontsize=18)
        # ax.set_title('Line Loading for Each Line with Area Grouping')

        plt.show()


    def busVoltageBarChart(self, df, max_bar_width=0.6):
        """This function creates bus voltage bar charts."""

        # Check if the dataframe is empty
        if df.empty:
            print("No busses below requirements. No chart will be generated.")
            return

        # Plot the data with uniform spacing on the x-axis
        fig, ax = plt.subplots(figsize=(12, 6))
        colors = plt.cm.hot((df['Voltage (pu)'] - 0.9) / 0.1)  # Color gradient from red to green

        # range for the x positions
        num_bars = len(df)
        bar_width = min(max_bar_width, 12 / num_bars)
        x_positions = range(num_bars)

        bars = ax.bar(x_positions, df['Voltage (pu)'], width=bar_width, color=colors)

        # x-axis labels
        ax.set_xticks(x_positions)
        ax.set_xticklabels([f"{row['name']} - {idx}: ({row['Vbase']} KV)" for idx, row in df.iterrows()], rotation=40, fontsize=14, ha='center')

        ax.tick_params(axis='y', labelsize=16)

        # labels and title
        ax.set_xlabel('Bus Information: Name - bus_id: (Voltage Level)', fontsize=18)
        ax.set_ylabel('Bus Voltage (pu)', fontsize=18)
        ax.set_ylim(0.9, 1.0)

        # horizontal line at 0.95 pu with description
        ax.axhline(y=0.95, color='black', linestyle='--', linewidth=1)
        ax.text(len(df) - 0.98, 0.951, 'Minimum requirement for connections at ≥ 300 KV', color='black', ha='right', va='bottom', fontsize=16, rotation=0)

        # Display the plot
        plt.tight_layout()
        plt.show()

    def calculate_ptdf(self, data):
        """Unused and Unfinished code. This function calculates a PTDF matrix."""
        # Extract necessary data from the case
        from pypower.loadcase import loadcase
        from pypower.ext2int import ext2int
        ppc = loadcase(data)

        ## convert to internal index
        ppc = ext2int(ppc)
        baseMVA, bus, gen, branch = \
            ppc["baseMVA"], ppc["bus"], ppc["gen"], ppc["branch"]

        #baseMVA, bus, gen, branch = ppc['baseMVA'], ppc['bus'], ppc['gen'], ppc['branch']

        # Number of buses and branches
        num_buses = bus.shape[0]
        num_branches = branch.shape[0]

        # Admittance matrix (Ybus)
        from pypower.makeYbus import makeYbus
        Ybus, Yf, Yt = makeYbus(baseMVA, bus, branch)

        # Base case voltage angles
        #V = base_case_results[0]['bus'][:, 8]  # Voltage angles in radians
        V = bus[:, 8]  # Voltage angles in radians

        # Branch susceptances
        B = np.imag(Ybus.toarray())

        # PTDF calculation
        PTDF = np.zeros((num_branches, num_buses))

        for i in range(num_buses):
            # Create a perturbation vector for bus i
            P = np.zeros(num_buses)
            #P[i] = 1.0  # Inject 1 MW at bus i
            P[i] = 100.0  # Inject 1 MW at bus i
            #?? Should be b instead

            # Solve for the voltage angle changes
            delta_theta = np.linalg.solve(B, P)

            for k in range(num_branches):
                from_bus = int(branch[k, 0]) - 1
                to_bus = int(branch[k, 1]) - 1
                PTDF[k, i] = (delta_theta[from_bus] - delta_theta[to_bus]) * branch[k, 2]  # PTDF formula  #should be X, so branch[k,3]

        return PTDF


